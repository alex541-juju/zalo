from zlapi import ZaloAPI
from zlapi.models import *
import time
from concurrent.futures import ThreadPoolExecutor
import threading
import os
import sys
import random
import json
import getpass

# File lưu thông tin đăng nhập
INFO_FILE = "in4.txt"

# === THÔNG TIN ADMIN (ĐÃ CẬP NHẬT UID CỦA BẠN) ===
ADMIN_ID = "835355022821204140"  # UID của bạn
ADMIN_NAME = "Admin"  # Tên hiển thị của bạn

# === COOKIES MỚI ===
COOKIES = {
    "zputm_source": "",
    "zputm_medium": "",
    "zputm_campaign": "",
    "zpsrc": "",
    "ZConsent": "timestamp=1787569981557&location=https://zalo.me/ott/",
    "_gid": "GA1.2.1507840943.1787569982",
    "__zi": "3000.SSZzejyD0jydXQckra00a3BBfxQL71AQV8UZjj1O4vvsZQ7-qrqSrNADgVdNNn_MCm.1",
    "__zi-legacy": "3000.SSZzejyD0jydXQckra00a3BBfxQL71AQV8UZjj1O4vvsZQ7-qrqSrNADgVdNNn_MCm.1",
    "_zlang": "vn",
    "app.event.zalo.me": "8028641932241512930",
    "_ga_YT9TMXZYV9": "GS2.1.s1787569934$o1$g1$t1787570918$j60$l0$h0",
    "_ga_YS1V643LGV": "GS2.1.s1787570957$o1$g0$t1787570958$j59$l0$h0",
    "_ga": "GA1.2.500963278.1787569934",
    "_ga_3EM8ZPYYN3": "GS2.2.s1787579667$o2$g0$t1787579667$j60$l0$h0",
    "zpsid": "f8kz.408854227.4.-W4eEhrTu1TkmxuFiLtW5yWkaYEDPTWYYM_I81QgiB6Pzlxbl7ojczTTu1S",
    "zpw_sek": "Zdbr.408854227.a0.RdRm_tcWhsZwrIe524jq7L9f4NOBSLPxNoS1LKvw0oGS2ZyiS1jCTsCD9NjUTaa_LE23JOzltmFRIbLGfI5q7G"
}

# IMEI
IMEI = "cdacc641-6257-418c-9ee1-10961ff411a2-3d96f8e03a42123e5523adf5c57607ad"

def load_info():
    """Đọc thông tin từ file in4.txt"""
    try:
        with open(INFO_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
            return data.get("imei"), data.get("cookies"), data.get("use_cookie", True)
    except (FileNotFoundError, json.JSONDecodeError):
        return None, None, True

def save_info(imei, cookies, use_cookie=True):
    """Lưu thông tin vào file in4.txt"""
    data = {
        "imei": imei,
        "cookies": cookies,
        "use_cookie": use_cookie
    }
    with open(INFO_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=4, ensure_ascii=False)

def get_imei():
    """Hỏi người dùng nhập IMEI"""
    print("\n" + "="*50)
    print("NHẬP IMEI")
    print("="*50)
    imei = input("IMEI (để trống dùng IMEI mặc định): ").strip()
    if not imei:
        return IMEI
    return imei

def get_cookies_input():
    """Hỏi người dùng nhập Cookies hoặc dùng cookies mặc định"""
    print("\n" + "="*50)
    print("NHẬP COOKIES")
    print("="*50)
    print("📌 Hướng dẫn lấy cookies:")
    print("1. Mở Zalo trên trình duyệt và đăng nhập")
    print("2. Nhấn F12 -> Application -> Cookies -> https://zalo.me")
    print("3. Copy toàn bộ cookies vào đây (dạng JSON)")
    print("="*50)
    
    use_default = input("Sử dụng cookies mặc định? (y/n, mặc định y): ").strip().lower()
    if use_default != 'n':
        print("✅ Sử dụng cookies mặc định!")
        return COOKIES, True
    
    use_cookie = input("Sử dụng cookies để đăng nhập? (y/n, mặc định y): ").strip().lower()
    if use_cookie == 'n':
        return None, False
    
    print("\n📝 Nhập cookies dạng JSON (hoặc để trống dùng cookies cũ):")
    cookies_input = input("Cookies: ").strip()
    
    if not cookies_input:
        _, old_cookies, _ = load_info()
        if old_cookies:
            print("Sử dụng cookies cũ")
            return old_cookies, True
        else:
            print("⚠️ Không tìm thấy cookies cũ! Sử dụng cookies mặc định.")
            return COOKIES, True
    
    try:
        # Thử parse JSON
        cookies = json.loads(cookies_input)
        if isinstance(cookies, dict):
            print("✅ Cookies hợp lệ!")
            return cookies, True
        else:
            print("❌ Cookies không đúng định dạng JSON! Sử dụng cookies mặc định.")
            return COOKIES, True
    except json.JSONDecodeError:
        print("❌ JSON không hợp lệ! Sử dụng cookies mặc định.")
        return COOKIES, True

def get_credentials():
    """Hỏi người dùng nhập phone và password (cách khác)"""
    print("\n" + "="*50)
    print("ĐĂNG NHẬP BẰNG SỐ ĐIỆN THOẠI")
    print("="*50)
    phone = input("Số điện thoại: ").strip()
    if not phone:
        return None, None
    
    password = getpass.getpass("Mật khẩu: ").strip()
    if not password:
        print("❌ Mật khẩu không được để trống!")
        return get_credentials()
    
    return phone, password

def login_with_retry():
    """Thử đăng nhập, nếu lỗi thì hỏi lại thông tin"""
    imei, cookies, use_cookie = load_info()
    
    if not imei or not cookies:
        print("\n🔄 Lần đầu chạy hoặc không có thông tin!")
        imei = get_imei()
        cookies, use_cookie = get_cookies_input()
        save_info(imei, cookies, use_cookie)
    
    return imei, cookies, use_cookie

class WxBotWar(ZaloAPI):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.prefix = "-"
        self.admin_id = ADMIN_ID
        self.admin_name = ADMIN_NAME
        self.auto_chatting = False
        self.start_time = time.time()
        self.copy_mode = False
        self.copy_target = set()
        self.spam_threads = []

    def is_admin(self, user_id):
        """Kiểm tra xem có phải admin không"""
        return str(user_id) == str(self.admin_id)

    def get_my_uid(self):
        """Lấy UID của chính mình"""
        try:
            profile = self.getProfile()
            return profile.get('userId')
        except:
            return None

    def sendTxt(self, filename, thread_id, thread_type, speed=1, concurrent=3):
        def auto_send():
            try:
                with open(filename, "r", encoding="utf-8") as f:
                    lines = [line.strip() for line in f if line.strip()]
                if not lines:
                    self.sendMessage(Message(text="File khong co gi"), thread_id, thread_type)
                    self.auto_chatting = False
                    return

                def send_worker():
                    index = 0
                    while self.auto_chatting:
                        try:
                            self.sendMessage(Message(text=lines[index % len(lines)]), thread_id, thread_type)
                            index += 1
                            time.sleep(speed / concurrent)
                        except Exception as e:
                            print(f"Send error: {e}")
                            time.sleep(0.5)

                workers = []
                for _ in range(concurrent):
                    t = threading.Thread(target=send_worker)
                    t.daemon = True
                    t.start()
                    workers.append(t)
                    time.sleep(0.1)

                for t in workers:
                    t.join()

            except FileNotFoundError:
                self.sendMessage(Message(text=f"Not {filename}"), thread_id, thread_type)
                self.auto_chatting = False
            except Exception as e:
                self.sendMessage(Message(text=f"{str(e)}"), thread_id, thread_type)
                self.auto_chatting = False

        threading.Thread(target=auto_send, daemon=True).start()

    def onMessage(self, mid, author_id, message, message_object, thread_id, thread_type):
        # Chỉ admin mới được dùng
        if not self.is_admin(author_id):
            print(f"⚠️ Tin nhắn từ người dùng thường: {author_id}: {message}")
            return
        
        thread.submit(self.onHandle, mid, author_id, message, message_object, thread_id, thread_type)
        print(f"✅ Tin nhắn từ Admin: {author_id}: {message}")
        
        if self.copy_mode and author_id in self.copy_target:
            self.replyMessage(
                Message(text=message),
                message_object,
                thread_id=thread_id,
                thread_type=thread_type
            )

    def onHandle(self, mid, author_id, message, message_object, thread_id, thread_type):
        # LỆNH HELP
        if message == f"{self.prefix}help":
            mention = Mention(self.admin_id, length=len(self.admin_name), offset=0)
            color = MessageStyle(style="color", color="cdd6f4", offset=0, length=3000, auto_format=False)
            smallfont = MessageStyle(style="font", size="13", offset=0, length=3000, auto_format=False)
            style = MultiMsgStyle([color, smallfont])
            
            ds_menu = f"""
╔══════════════════════════════════════╗
║      📋 DANH SÁCH LỆNH BOT         ║
╠══════════════════════════════════════╣
║ {self.prefix}help     : Hiển thị danh sách lệnh ║
║ {self.prefix}uid      : Lấy UID người dùng      ║
║ {self.prefix}uptime   : Thời gian bot hoạt động ║
║ {self.prefix}reset    : Khởi động lại bot       ║
║ {self.prefix}1c       : Chế độ 1c               ║
║ {self.prefix}war      : Chế độ war              ║
║ {self.prefix}chui     : Chế độ chửi (tag)       ║
║ {self.prefix}so       : Chế độ sớ               ║
║ {self.prefix}nhay     : Chế độ nhây (spam cực)  ║
║ {self.prefix}copy     : Copy tin nhắn           ║
║ {self.prefix}treo     : Chế độ treo             ║
║ {self.prefix}tagall   : Tag tất cả thành viên   ║
║ {self.prefix}xbdz     : Treo + tagall           ║
╚══════════════════════════════════════╝
            """
            
            self.replyMessage(
                Message(text=f"@{self.admin_name} {ds_menu}", style=style, mention=mention),
                message_object,
                thread_id=thread_id,
                thread_type=thread_type
            )

        # LỆNH LẤY UID
        elif message.startswith(f"{self.prefix}uid"):
            if message_object.mentions:
                tagged_users = message_object.mentions[0]['uid']
            else:
                tagged_users = author_id
            response_message = f"UID: {tagged_users}"
            message_to_send = Message(text=response_message)
            self.replyMessage(message_to_send, message_object, thread_id, thread_type)

        # LỆNH UPTIME
        elif message.startswith(f"{self.prefix}uptime"):
            uptime = time.time() - self.start_time
            days, remainder = divmod(uptime, 86400)
            hours, remainder = divmod(remainder, 3600)
            minutes, seconds = divmod(remainder, 60)
            uptime_str = f"{int(days)} days, {int(hours)} hours, {int(minutes)} minutes, {int(seconds)} seconds"
            self.sendMessage(Message(text=f"⏰ Uptime: {uptime_str}"), thread_id, thread_type)
        
        # LỆNH RESET
        elif message.startswith(f"{self.prefix}reset"):
            self.sendMessage(Message(text="🔄 Đang khởi động lại bot..."), thread_id, thread_type)
            time.sleep(1)
            os.execv(sys.executable, [sys.executable] + sys.argv)

        # LỆNH 1C
        elif message.startswith(f"{self.prefix}1c"):
            if message.strip() == f"{self.prefix}1c off":
                self.auto_chatting = False
                self.sendMessage(Message(text="⏹️ Đã dừng chế độ 1c!"), thread_id, thread_type)
            else:
                if self.auto_chatting:
                    self.sendMessage(Message(text="⚠️ Bot đang chạy, vui lòng tắt trước!"), thread_id, thread_type)
                else:
                    filename = "1c.txt" 
                    self.auto_chatting = True
                    self.sendTxt(filename, thread_id, thread_type, speed=0.5, concurrent=5)
                    self.sendMessage(Message(text="▶️ Đã bật chế độ 1c!"), thread_id, thread_type)

        # LỆNH WAR
        elif message.startswith(f"{self.prefix}war"):
            if message.strip() == f"{self.prefix}war off":
                self.auto_chatting = False
                self.sendMessage(Message(text="⏹️ Đã dừng chế độ war!"), thread_id, thread_type)
            else:
                if self.auto_chatting:
                    self.sendMessage(Message(text="⚠️ Bot đang chạy, vui lòng tắt trước!"), thread_id, thread_type)
                else:
                    filename = "nhay.txt"
                    self.auto_chatting = True
                    self.sendTxt(filename, thread_id, thread_type, speed=0.3, concurrent=8)
                    self.sendMessage(Message(text="▶️ Đã bật chế độ war!"), thread_id, thread_type)

        # LỆNH CHỬI
        elif message.startswith(f"{self.prefix}chui"):
            if message.strip() == f"{self.prefix}chui off":
                self.auto_chatting = False
                self.sendMessage(Message(text="⏹️ Đã dừng chế độ chửi!"), thread_id, thread_type)
            else:
                if self.auto_chatting:
                    self.sendMessage(Message(text="⚠️ Bot đang chạy, vui lòng tắt trước!"), thread_id, thread_type)
                else:
                    if not message_object.mentions:
                        self.sendMessage(Message(text="❌ Vui lòng tag người cần chửi!"), thread_id, thread_type)
                        return

                    filename = "nhay.txt"
                    self.auto_chatting = True

                    def send_tagged():
                        try:
                            with open(filename, "r", encoding="utf-8") as f:
                                lines = [line.strip() for line in f if line.strip()]
                            if not lines:
                                self.sendMessage(Message(text="File không có gì"), thread_id, thread_type)
                                self.auto_chatting = False
                                return
                            tagged_uid = message_object.mentions[0]['uid']
                            
                            def tag_worker():
                                index = 0
                                while self.auto_chatting:
                                    try:
                                        traloi = lines[index % len(lines)] + " @member"
                                        offset = len(lines[index % len(lines)]) + 1
                                        mention = Mention(tagged_uid, offset=offset, length=8)
                                        self.send(
                                            Message(text=traloi, mention=mention),
                                            thread_id,
                                            thread_type
                                        )
                                        index += 1
                                        time.sleep(0.2)
                                    except Exception as e:
                                        print(f"Tag send error: {e}")
                                        time.sleep(0.5)
                            
                            workers = []
                            for _ in range(3):
                                t = threading.Thread(target=tag_worker)
                                t.daemon = True
                                t.start()
                                workers.append(t)
                            
                            for t in workers:
                                t.join()
                                
                        except FileNotFoundError:
                            self.sendMessage(Message(text=f"Không tìm thấy file {filename}"), thread_id, thread_type)
                            self.auto_chatting = False
                        except Exception as e:
                            self.sendMessage(Message(text=f"Lỗi: {str(e)}"), thread_id, thread_type)
                            self.auto_chatting = False

                    threading.Thread(target=send_tagged, daemon=True).start()
                    self.sendMessage(Message(text="▶️ Đã bật chế độ chửi!"), thread_id, thread_type)

        # LỆNH SỚ
        elif message.startswith(f"{self.prefix}so"):
            if message.strip() == f"{self.prefix}so off":
                self.auto_chatting = False
                self.sendMessage(Message(text="⏹️ Đã dừng chế độ sớ!"), thread_id, thread_type)
            else:
                if self.auto_chatting:
                    self.sendMessage(Message(text="⚠️ Bot đang chạy, vui lòng tắt trước!"), thread_id, thread_type)
                else:
                    filename = "so.txt" 
                    self.auto_chatting = True
                    self.sendTxt(filename, thread_id, thread_type, speed=0.5, concurrent=5)
                    self.sendMessage(Message(text="▶️ Đã bật chế độ sớ!"), thread_id, thread_type)

        # LỆNH NHAY (SPAM CỰC MẠNH)
        elif message.startswith(f"{self.prefix}nhay"):
            if message.strip() == f"{self.prefix}nhay off":
                self.auto_chatting = False
                self.sendMessage(Message(text="⏹️ Đã dừng chế độ nhây!"), thread_id, thread_type)
            else:
                if self.auto_chatting:
                    self.sendMessage(Message(text="⚠️ Bot đang chạy, vui lòng tắt trước!"), thread_id, thread_type)
                else:
                    filename = "nhay.txt" 
                    self.auto_chatting = True
                    self.sendTxt(filename, thread_id, thread_type, speed=0.2, concurrent=10)
                    self.sendMessage(Message(text="▶️ Đã bật chế độ nhây (spam cực mạnh)!"), thread_id, thread_type)
        
        # LỆNH COPY
        elif message.startswith(f"{self.prefix}copy"):
            if message.strip() == f"{self.prefix}copy off":
                self.copy_mode = False
                self.copy_target.clear()
                self.sendMessage(Message(text="⏹️ Đã tắt chế độ copy!"), thread_id, thread_type)
            elif message_object.mentions:
                self.copy_target = set(m['uid'] for m in message_object.mentions)
                self.copy_mode = True
                self.sendMessage(Message(text="▶️ Đã bật chế độ copy!"), thread_id, thread_type)
            else:
                self.sendMessage(Message(text="❌ Vui lòng tag người cần copy!"), thread_id, thread_type)

        # LỆNH TREO
        elif message.startswith(f"{self.prefix}treo"):
            if message.strip() == f"{self.prefix}treo off":
                self.auto_chatting = False
                self.sendMessage(Message(text="⏹️ Đã dừng chế độ treo!"), thread_id, thread_type)
            else:
                def send_all_repeat():
                    try:
                        with open("ngontreo.txt", "r", encoding="utf-8") as f:
                            content = f.read().strip()
                        if not content:
                            self.sendMessage(Message(text="File khong co gi"), thread_id, thread_type)
                            return
                        self.auto_chatting = True
                        
                        def repeat_worker():
                            while self.auto_chatting:
                                try:
                                    self.sendMessage(Message(text=content), thread_id, thread_type)
                                    time.sleep(1)
                                except Exception as e:
                                    print(f"Repeat error: {e}")
                                    time.sleep(0.5)
                        
                        workers = []
                        for _ in range(5):
                            t = threading.Thread(target=repeat_worker)
                            t.daemon = True
                            t.start()
                            workers.append(t)
                        
                        for t in workers:
                            t.join()
                            
                    except Exception as e:
                        self.sendMessage(Message(text=f"Lỗi: {e}"), thread_id, thread_type)
                        self.auto_chatting = False
                threading.Thread(target=send_all_repeat, daemon=True).start()
                self.sendMessage(Message(text="▶️ Đã bật chế độ treo!"), thread_id, thread_type)

        # LỆNH XBDZ (TREO + TAGALL)
        elif message.startswith(f"{self.prefix}xbdz"):
            if message.strip() == f"{self.prefix}xbdz off":
                self.auto_chatting = False
                self.sendMessage(Message(text="⏹️ Đã dừng chế độ xbdz!"), thread_id, thread_type)
            else:
                def send_treotagall():
                    try:
                        with open("ngontreo.txt", "r", encoding="utf-8") as f:
                            content = f.read().strip()
                        if not content:
                            self.sendMessage(Message(text="File khong co gi"), thread_id, thread_type)
                            return
                        self.auto_chatting = True
                        group_info = self.fetchGroupInfo(thread_id).gridInfoMap[thread_id]
                        thanhvien = group_info.get('memVerList', [])
                        mention = [Mention(userId.split('_')[0], length=3000, offset=0, auto_format=False) for userId in thanhvien]
                        wjxz_mention = MultiMention(mention)
                        
                        def tagall_worker():
                            while self.auto_chatting:
                                try:
                                    self.send(Message(text=content, mention=wjxz_mention), thread_id, thread_type)
                                    time.sleep(0.5)
                                except Exception as e:
                                    print(f"Tagall error: {e}")
                                    time.sleep(0.5)
                        
                        workers = []
                        for _ in range(3):
                            t = threading.Thread(target=tagall_worker)
                            t.daemon = True
                            t.start()
                            workers.append(t)
                        
                        for t in workers:
                            t.join()
                            
                    except Exception as e:
                        self.sendMessage(Message(text=f"Lỗi: {e}"), thread_id, thread_type)
                        self.auto_chatting = False
                threading.Thread(target=send_treotagall, daemon=True).start()
                self.sendMessage(Message(text="▶️ Đã bật chế độ xbdz (treo + tagall)!"), thread_id, thread_type)

        # LỆNH TAGALL
        elif message.startswith(f"{self.prefix}tagall"):
            content = message.strip().split(' ', 1)
            if len(content) < 2:
                self.replyMessage(Message(text="❌ Vui lòng nhập nội dung cần tag!"), message_object, thread_id, thread_type)
                return
            try:
                wjx = content[1]
                group_info = self.fetchGroupInfo(thread_id).gridInfoMap[thread_id]
                thanhvien = group_info.get('memVerList', [])
                mention = [Mention(userId.split('_')[0], length=3000, offset=0, auto_format=False) for userId in thanhvien]
                wjxz_mention = MultiMention(mention)
                self.send(Message(text=wjx, mention=wjxz_mention), thread_id, thread_type)
            except Exception as e:
                print(f"Error: {e}")
                self.sendMessage(Message(text=f"❌ Lỗi: {e}"), thread_id, thread_type)

def main():
    """Hàm chính để chạy bot"""
    print("\n" + "="*60)
    print("🤖 ZALO BOT WAR - MULTI THREAD SPAM")
    print("="*60)
    print(f"👤 Admin ID: {ADMIN_ID}")
    print(f"📛 Admin Name: {ADMIN_NAME}")
    print("="*60)
    
    # Load hoặc hỏi thông tin đăng nhập
    imei, cookies, use_cookie = login_with_retry()
    
    # Thử đăng nhập
    try:
        print("\n🔄 Đang đăng nhập vào Zalo...")
        if use_cookie and cookies:
            bot = WxBotWar(imei=imei, session_cookies=cookies)
            print("✅ Đăng nhập thành công bằng Cookies!")
        else:
            # Nếu không dùng cookie, hỏi số điện thoại và mật khẩu
            print("\n📱 Đăng nhập bằng số điện thoại")
            phone, password = get_credentials()
            if phone and password:
                bot = WxBotWar(phone=phone, password=password, imei=imei)
                print("✅ Đăng nhập thành công bằng số điện thoại!")
            else:
                print("❌ Không có thông tin đăng nhập!")
                return
        
        # Lấy UID của bạn để xác nhận
        try:
            my_uid = bot.get_my_uid()
            if my_uid:
                print(f"\n✅ UID CỦA BẠN: {my_uid}")
                if str(my_uid) == ADMIN_ID:
                    print("✅ UID khớp với ADMIN_ID!")
                else:
                    print(f"⚠️ UID không khớp! ADMIN_ID hiện tại: {ADMIN_ID}")
            else:
                print("\n⚠️ Không thể lấy UID")
        except:
            pass
        
        print("\n🚀 Bot đang chạy...")
        print("📌 Chỉ Admin mới có thể sử dụng bot!")
        print("📌 Lệnh help: -help")
        print("="*60 + "\n")
        bot.listen()
        
    except Exception as e:
        print(f"\n❌ Lỗi đăng nhập: {e}")
        print("\n🔄 Cookies có thể đã hết hạn! Hãy cập nhật cookies mới.")
        
        # Hỏi lại thông tin
        choice = input("\nBạn muốn:\n1. Nhập lại Cookies mới\n2. Nhập lại IMEI\n3. Thoát\nChọn (1/2/3): ").strip()
        
        if choice == "1":
            print("\n📝 Nhập cookies mới:")
            new_cookies, _ = get_cookies_input()
            if new_cookies:
                save_info(imei, new_cookies, True)
                print("✅ Đã lưu cookies mới! Khởi động lại bot...")
                time.sleep(2)
                os.execv(sys.executable, [sys.executable] + sys.argv)
            else:
                print("❌ Cookies không hợp lệ!")
        elif choice == "2":
            new_imei = get_imei()
            if new_imei:
                save_info(new_imei, cookies, True)
                print("✅ Đã lưu IMEI mới! Khởi động lại bot...")
                time.sleep(2)
                os.execv(sys.executable, [sys.executable] + sys.argv)
        else:
            print("👋 Tạm biệt!")

if __name__ == "__main__":
    main()