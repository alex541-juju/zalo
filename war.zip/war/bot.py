from zlapi import ZaloAPI
from zlapi.models import *
import time
from concurrent.futures import ThreadPoolExecutor
import threading
import os
import sys

# Replace with your imei and cookies
imei = "cdacc641-6257-418c-9ee1-10961ff411a2-3d96f8e03a42123e5523adf5c57607ad"
cookies = {"zputm_source":"","zputm_medium":"","zputm_campaign":"","zpsrc":"","ZConsent":"timestamp=1787569981557&location=https://zalo.me/ott/","_gid":"GA1.2.1507840943.1787569982","__zi":"3000.SSZzejyD0jydXQckra00a3BBfxQL71AQV8UZjj1O4vvsZQ7-qrqSrNADgVdNNn_MCm.1","__zi-legacy":"3000.SSZzejyD0jydXQckra00a3BBfxQL71AQV8UZjj1O4vvsZQ7-qrqSrNADgVdNNn_MCm.1","_zlang":"vn","app.event.zalo.me":"8028641932241512930","_ga_YT9TMXZYV9":"GS2.1.s1787569934$o1$g1$t1787570918$j60$l0$h0","_ga_YS1V643LGV":"GS2.1.s1787580996$o2$g0$t1787580999$j57$l0$h0","_ga":"GA1.2.500963278.1787569934","_ga_3EM8ZPYYN3":"GS2.2.s1787579667$o2$g1$t1787581002$j60$l0$h0","zpsid":"McFE.408854227.5.dPyt_AIP-TDt1wVBg9dvqz7gY-UKeS7caAlBv0zkgNM0CkSXfSohNywP-TC","zpw_sek":"Ruc4.408854227.a0.NQ1Nt0ZEtWQBkrjhUIK5SoC7O1Xw7oSWR7HiGMveK2SiKou38dDsDH50J3a_63XH9Oxo8_u1hcsg95CXr4y5Sm"}

thread = ThreadPoolExecutor(max_workers=10000)

class WxBotWar(ZaloAPI):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.prefix = "-"
        self.start_time = time.time()
        self.copy_mode = False
        self.copy_target = set()
        self.thread_running = {}  # Lưu trạng thái từng thread
        self.active_threads = {}  # Lưu thread objects

    def send_spam(self, filename, thread_id, thread_type, thread_key, mention_uid=None):
        def spam_loop():
            try:
                # Kiểm tra file tồn tại
                if not os.path.exists(filename):
                    self.sendMessage(Message(text=f"❌ Khong tim thay file {filename}"), thread_id, thread_type)
                    self.thread_running[thread_key] = False
                    return
                    
                with open(filename, "r", encoding="utf-8") as f:
                    lines = [line.strip() for line in f if line.strip()]
                
                if not lines:
                    self.sendMessage(Message(text="❌ File rong"), thread_id, thread_type)
                    self.thread_running[thread_key] = False
                    return

                print(f"✅ Da tai {len(lines)} dong tu {filename}")
                index = 0
                count = 0
                
                while self.thread_running.get(thread_key, False):
                    text = lines[index]
                    
                    # Nếu có mention thì thêm @member
                    if mention_uid:
                        text += " @member"
                        offset = len(lines[index]) + 1
                        mention = Mention(mention_uid, offset=offset, length=8)
                        self.send(Message(text=text, mention=mention), thread_id, thread_type)
                    else:
                        self.sendMessage(Message(text=text), thread_id, thread_type)
                    
                    index = (index + 1) % len(lines)
                    count += 1
                    print(f"📤 Da gui {count} tin nhan")
                    time.sleep(0.3)  # Spam nhanh
                    
            except Exception as e:
                print(f"❌ Loi spam: {e}")
                self.sendMessage(Message(text=f"❌ Loi: {str(e)}"), thread_id, thread_type)
                self.thread_running[thread_key] = False

        # Tắt thread cũ nếu có
        if thread_key in self.active_threads:
            self.thread_running[thread_key] = False
            time.sleep(0.5)
            try:
                if self.active_threads[thread_key].is_alive():
                    self.active_threads[thread_key].join(timeout=1)
            except:
                pass
            del self.active_threads[thread_key]

        # Khởi tạo thread mới
        self.thread_running[thread_key] = True
        t = threading.Thread(target=spam_loop)
        self.active_threads[thread_key] = t
        t.start()
        print(f"🚀 Started spam thread: {thread_key}")

    def onMessage(self, mid, author_id, message, message_object, thread_id, thread_type):
        thread.submit(self.onHandle, mid, author_id, message, message_object, thread_id, thread_type)
        print(f"📩 Tin nhan: {author_id}: {message}")
        
        # Copy mode
        if self.copy_mode and author_id in self.copy_target:
            self.replyMessage(
                Message(text=message),
                message_object,
                thread_id=thread_id,
                thread_type=thread_type
            )

    def onHandle(self, mid, author_id, message, message_object, thread_id, thread_type):
        thread_key = f"{thread_id}_{thread_type}"
        
        if message == f"{self.prefix}menu":
            menu = """
📋 dev by alex541 
━━━━━━━━━━━━━━━━━━━━━
「𖤐」 {prefix}help - Hien thi menu
「𖤐」 {prefix}uid - Lay UID cua ban
「𖤐」 {prefix}uptime - Xem thoi gian bot chay
「𖤐」 {prefix}reset - Khoi dong lai bot
「𖤐」 {prefix}1c - Spam file 1c.txt
「𖤐」 {prefix}war - Spam file nhay.txt
「𖤐」 {prefix}chui - Tag va chui nguoi dung
「𖤐」 {prefix}so - Spam file so.txt
「𖤐」 {prefix}nhay - Spam file nhay.txt
「𖤐」 {prefix}copy - Copy tin nhan
「𖤐」 {prefix}treo - Spam file ngontreo.txt
「𖤐」 {prefix}nuke - Spam file ngontreo.txt + tag all
「𖤐」 {prefix}tagall - Tag tat ca thanh vien
━━━━━━━━━━━━━━━━━━━━━
♡ Them 'off' sau lenh de tat
♡ VD: {prefix}1c off
            """.format(prefix=self.prefix)
            
            style = MultiMsgStyle([
                MessageStyle(style="color", color="#cdd6f4", offset=0, length=len(menu), auto_format=False),
                MessageStyle(style="font", size="13", offset=0, length=len(menu), auto_format=False)
            ])
            
            self.replyMessage(
                Message(text=menu, style=style),
                message_object,
                thread_id=thread_id,
                thread_type=thread_type
            )
            return

        # ============ LỆNH UID ============
        if message.startswith(f"{self.prefix}uid"):
            if message_object.mentions:
                tagged_users = message_object.mentions[0]['uid']
            else:
                tagged_users = author_id
            self.replyMessage(
                Message(text=f"UID: {tagged_users}"),
                message_object,
                thread_id=thread_id,
                thread_type=thread_type
            )
            return

        # ============ LỆNH UPTIME ============
        if message.startswith(f"{self.prefix}uptime"):
            uptime = time.time() - self.start_time
            days, remainder = divmod(uptime, 86400)
            hours, remainder = divmod(remainder, 3600)
            minutes, seconds = divmod(remainder, 60)
            uptime_str = f"{int(days)} ngay, {int(hours)} gio, {int(minutes)} phut, {int(seconds)} giay"
            self.sendMessage(
                Message(text=f"🕐 Bot hoat dong: {uptime_str}"),
                thread_id,
                thread_type
            )
            return

        # ============ LỆNH RESET ============
        if message.startswith(f"{self.prefix}reset"):
            self.sendMessage(Message(text="🔄 Dang khoi dong lai bot..."), thread_id, thread_type)
            os.execv(sys.executable, [sys.executable] + sys.argv)
            return

        # ============ LỆNH 1C ============
        if message.startswith(f"{self.prefix}1c"):
            if "off" in message:
                self.thread_running[thread_key] = False
                self.sendMessage(Message(text="👀 Da tat 1c"), thread_id, thread_type)
            else:
                if self.thread_running.get(thread_key, False):
                    self.sendMessage(Message(text="⚠ Dang chay, hay tat truoc"), thread_id, thread_type)
                else:
                    self.send_spam("1c.txt", thread_id, thread_type, thread_key)
            return

        # ============ LỆNH WAR ============
        if message.startswith(f"{self.prefix}war"):
            if "off" in message:
                self.thread_running[thread_key] = False
                self.sendMessage(Message(text="⏹ Da tat war"), thread_id, thread_type)
            else:
                if self.thread_running.get(thread_key, False):
                    self.sendMessage(Message(text="⚠ Dang chay, hay tat truoc"), thread_id, thread_type)
                else:
                    self.send_spam("nhay.txt", thread_id, thread_type, thread_key)
            return

        # ============ LỆNH CHUI ============
        if message.startswith(f"{self.prefix}chui"):
            if "off" in message:
                self.thread_running[thread_key] = False
                self.sendMessage(Message(text="👀 Da tat chui"), thread_id, thread_type)
            else:
                if self.thread_running.get(thread_key, False):
                    self.sendMessage(Message(text="⚠ Dang chay, hay tat truoc"), thread_id, thread_type)
                elif message_object.mentions:
                    tagged_uid = message_object.mentions[0]['uid']
                    self.send_spam("nhay.txt", thread_id, thread_type, thread_key, tagged_uid)
                else:
                    self.sendMessage(Message(text="👤 Tag nguoi can chui"), thread_id, thread_type)
            return

        # ============ LỆNH SO ============
        if message.startswith(f"{self.prefix}so"):
            if "off" in message:
                self.thread_running[thread_key] = False
                self.sendMessage(Message(text="👀 Da tat so"), thread_id, thread_type)
            else:
                if self.thread_running.get(thread_key, False):
                    self.sendMessage(Message(text="⚠ Dang chay, hay tat truoc"), thread_id, thread_type)
                else:
                    self.send_spam("so.txt", thread_id, thread_type, thread_key)
            return

        # ============ LỆNH NHAY ============
        if message.startswith(f"{self.prefix}nhay"):
            if "off" in message:
                self.thread_running[thread_key] = False
                self.sendMessage(Message(text="👀 Da tat nhay"), thread_id, thread_type)
            else:
                if self.thread_running.get(thread_key, False):
                    self.sendMessage(Message(text="⚠ Dang chay, hay tat truoc"), thread_id, thread_type)
                else:
                    self.send_spam("nhay.txt", thread_id, thread_type, thread_key)
            return

        # ============ LỆNH COPY ============
        if message.startswith(f"{self.prefix}copy"):
            if "off" in message:
                self.copy_mode = False
                self.copy_target.clear()
                self.sendMessage(Message(text="📋 Copy mode OFF!"), thread_id, thread_type)
            elif message_object.mentions:
                self.copy_target = set(m['uid'] for m in message_object.mentions)
                self.copy_mode = True
                self.sendMessage(Message(text="📋 Copy mode ON!"), thread_id, thread_type)
            else:
                self.sendMessage(Message(text="👤 Tag nguoi can copy!"), thread_id, thread_type)
            return

        # ============ LỆNH TREO ============
        if message.startswith(f"{self.prefix}treo"):
            if "off" in message:
                self.thread_running[thread_key] = False
                self.sendMessage(Message(text="👀 Da tat treo"), thread_id, thread_type)
            else:
                if self.thread_running.get(thread_key, False):
                    self.sendMessage(Message(text="⚠ Dang chay, hay tat truoc"), thread_id, thread_type)
                else:
                    self.send_spam("ngontreo.txt", thread_id, thread_type, thread_key)
            return

        # ============ LỆNH NUKE (spam ngontreo.txt + tag all) ============
        if message.startswith(f"{self.prefix}nuke"):
            if "off" in message:
                self.thread_running[thread_key] = False
                self.sendMessage(Message(text="👀 Da tat nuke"), thread_id, thread_type)
            else:
                if self.thread_running.get(thread_key, False):
                    self.sendMessage(Message(text="⚠ Dang chay, hay tat truoc"), thread_id, thread_type)
                else:
                    def send_nuke():
                        try:
                            # Kiểm tra file tồn tại
                            if not os.path.exists("ngontreo.txt"):
                                self.sendMessage(Message(text="❌ Khong tim thay file ngontreo.txt"), thread_id, thread_type)
                                self.thread_running[thread_key] = False
                                return
                            
                            # Đọc nội dung file
                            with open("ngontreo.txt", "r", encoding="utf-8") as f:
                                lines = [line.strip() for line in f if line.strip()]
                                
                            if not lines:
                                self.sendMessage(Message(text="❌ File rong"), thread_id, thread_type)
                                self.thread_running[thread_key] = False
                                return
                            
                            print(f"✅ Da tai {len(lines)} dong tu ngontreo.txt")
                            
                            # Lấy danh sách thành viên
                            group_info = self.fetchGroupInfo(thread_id).gridInfoMap[thread_id]
                            thanhvien = group_info.get('memVerList', [])
                            
                            if not thanhvien:
                                self.sendMessage(Message(text="❌ Khong lay duoc danh sach thanh vien"), thread_id, thread_type)
                                self.thread_running[thread_key] = False
                                return
                            
                            # Tạo mention cho tất cả thành viên
                            mention = [Mention(userId.split('_')[0], length=3000, offset=0, auto_format=False) for userId in thanhvien]
                            wjxz_mention = MultiMention(mention)
                            
                            self.thread_running[thread_key] = True
                            index = 0
                            count = 0
                            
                            while self.thread_running.get(thread_key, False):
                                text = lines[index]
                                # Gửi tin nhắn với tag all
                                self.send(Message(text=text, mention=wjxz_mention), thread_id, thread_type)
                                index = (index + 1) % len(lines)
                                count += 1
                                print(f"💥 Da gui {count} tin nhan NUKE")
                                time.sleep(0.3)  # Spam nhanh
                                
                        except Exception as e:
                            print(f"❌ Loi nuke: {e}")
                            self.sendMessage(Message(text=f"❌ Loi: {str(e)}"), thread_id, thread_type)
                            self.thread_running[thread_key] = False
                    
                    # Tắt thread cũ nếu có
                    if thread_key in self.active_threads:
                        self.thread_running[thread_key] = False
                        time.sleep(0.5)
                        try:
                            if self.active_threads[thread_key].is_alive():
                                self.active_threads[thread_key].join(timeout=1)
                        except:
                            pass
                        del self.active_threads[thread_key]
                    
                    # Khởi tạo thread mới
                    self.thread_running[thread_key] = True
                    t = threading.Thread(target=send_nuke)
                    self.active_threads[thread_key] = t
                    t.start()
                    print(f"💥 Started NUKE thread: {thread_key}")
            return

        # ============ LỆNH TAGALL ============
        if message.startswith(f"{self.prefix}tagall"):
            parts = message.strip().split(' ', 1)
            if len(parts) < 2:
                self.replyMessage(
                    Message(text="💬 Vui long nhap noi dung can tag"),
                    message_object,
                    thread_id=thread_id,
                    thread_type=thread_type
                )
                return
                
            try:
                content = parts[1]
                group_info = self.fetchGroupInfo(thread_id).gridInfoMap[thread_id]
                thanhvien = group_info.get('memVerList', [])
                
                if not thanhvien:
                    self.sendMessage(Message(text="❌ Khong lay duoc danh sach thanh vien"), thread_id, thread_type)
                    return
                    
                mention = [Mention(userId.split('_')[0], length=3000, offset=0, auto_format=False) for userId in thanhvien]
                wjxz_mention = MultiMention(mention)
                self.send(Message(text=content, mention=wjxz_mention), thread_id, thread_type)
                
            except Exception as e:
                print(f"❌ Loi tagall: {e}")
                self.sendMessage(Message(text=f"❌ Loi: {str(e)}"), thread_id, thread_type)
            return

# Khởi tạo và chạy bot
if __name__ == "__main__":
    try:
        bot = WxBotWar("<API_KEY>", "<SECRET_KEY>", imei=imei, session_cookies=cookies)
        print("🤖 Bot dang chay...")
        bot.listen()
    except Exception as e:
        print(f"❌ Loi khoi dong bot: {e}")