from zlapi import ZaloAPI
from zlapi.models import *
import time
import threading
import os
import sys
from concurrent.futures import ThreadPoolExecutor, as_completed
import queue
import random

# Cấu hình
THREAD_POOL_SIZE = 50  # Số luồng tối đa
BATCH_SIZE = 10  # Số tin nhắn gửi mỗi lần
SEND_DELAY = 0.1  # Delay giữa các tin nhắn (giây)

class WxBotWar(ZaloAPI):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.prefix = "-"
        self.idadmin = ["835355022821204140"]
        self.auto_chatting = False
        self.start_time = time.time()
        self.copy_mode = False
        self.copy_target = set()
        
        # Multi-thread pool cho spam
        self.spam_pool = ThreadPoolExecutor(max_workers=THREAD_POOL_SIZE)
        self.message_queue = queue.Queue()
        self.spam_threads = []
        self.is_spamming = False
        
        # Khởi tạo worker threads
        self._init_spam_workers()

    def _init_spam_workers(self):
        """Khởi tạo các worker threads để xử lý spam"""
        def worker():
            while True:
                try:
                    # Lấy tin nhắn từ queue
                    msg_data = self.message_queue.get(timeout=1)
                    if msg_data is None:  # Signal để dừng
                        break
                    
                    text, thread_id, thread_type, mention = msg_data
                    
                    # Gửi tin nhắn với mention nếu có
                    if mention:
                        self.send(Message(text=text, mention=mention), thread_id, thread_type)
                    else:
                        self.send(Message(text=text), thread_id, thread_type)
                    
                    time.sleep(SEND_DELAY)
                except queue.Empty:
                    continue
                except Exception as e:
                    print(f"Worker error: {e}")

        # Tạo các worker threads
        for _ in range(THREAD_POOL_SIZE):
            t = threading.Thread(target=worker, daemon=True)
            t.start()
            self.spam_threads.append(t)

    def send_message_batch(self, messages, thread_id, thread_type, mention=None):
        """Gửi nhiều tin nhắn cùng lúc sử dụng multi-threads"""
        def send_single(msg):
            if mention:
                self.send(Message(text=msg, mention=mention), thread_id, thread_type)
            else:
                self.send(Message(text=msg), thread_id, thread_type)
            time.sleep(0.05)  # Delay nhỏ để tránh bị block

        # Gửi tin nhắn theo batch
        for i in range(0, len(messages), BATCH_SIZE):
            batch = messages[i:i+BATCH_SIZE]
            futures = []
            
            for msg in batch:
                future = self.spam_pool.submit(send_single, msg)
                futures.append(future)
            
            # Đợi batch hiện tại hoàn thành
            for future in as_completed(futures):
                try:
                    future.result()
                except Exception as e:
                    print(f"Send error: {e}")
            
            # Delay giữa các batch
            time.sleep(0.1)

    def spam_with_tag(self, filename, thread_id, thread_type, tagged_uid=None):
        """Spam tin nhắn với mention cho tagged user"""
        def spam_worker():
            try:
                with open(filename, "r", encoding="utf-8") as f:
                    lines = [line.strip() for line in f if line.strip()]
                
                if not lines:
                    self.sendMessage(Message(text="File khong co gi"), thread_id, thread_type)
                    self.auto_chatting = False
                    return
                
                index = 0
                message_count = 0
                max_messages = 1000  # Giới hạn số tin nhắn để tránh spam quá mức
                
                while self.auto_chatting and message_count < max_messages:
                    # Tạo danh sách tin nhắn để gửi batch
                    batch_messages = []
                    for _ in range(min(BATCH_SIZE, len(lines))):
                        if tagged_uid:
                            msg = lines[index] + " @member"
                            offset = len(lines[index]) + 1
                            mention = Mention(tagged_uid, offset=offset, length=8)
                            batch_messages.append((msg, mention))
                        else:
                            batch_messages.append((lines[index], None))
                        
                        index = (index + 1) % len(lines)
                        message_count += 1
                    
                    # Gửi batch tin nhắn
                    futures = []
                    for msg, mention in batch_messages:
                        future = self.spam_pool.submit(
                            self.send, 
                            Message(text=msg, mention=mention) if mention else Message(text=msg),
                            thread_id,
                            thread_type
                        )
                        futures.append(future)
                    
                    # Đợi batch hoàn thành
                    for future in as_completed(futures):
                        try:
                            future.result()
                        except Exception as e:
                            print(f"Send error: {e}")
                    
                    time.sleep(0.1)  # Delay giữa các batch
                    
            except FileNotFoundError:
                self.sendMessage(Message(text=f"Khong tim thay file {filename}"), thread_id, thread_type)
                self.auto_chatting = False
            except Exception as e:
                self.sendMessage(Message(text=f"Loi: {str(e)}"), thread_id, thread_type)
                self.auto_chatting = False

        threading.Thread(target=spam_worker, daemon=True).start()

    def sendTxt(self, filename, thread_id, thread_type):
        """Gửi tin nhắn từ file với multi-threads"""
        def auto_send():
            try:
                with open(filename, "r", encoding="utf-8") as f:
                    lines = [line.strip() for line in f if line.strip()]
                
                if not lines:
                    self.sendMessage(Message(text="File khong co gi"), thread_id, thread_type)
                    self.auto_chatting = False
                    return
                
                index = 0
                while self.auto_chatting:
                    # Gửi batch tin nhắn
                    batch = []
                    for _ in range(min(BATCH_SIZE, len(lines))):
                        batch.append(lines[index])
                        index = (index + 1) % len(lines)
                    
                    self.send_message_batch(batch, thread_id, thread_type)
                    time.sleep(0.05)  # Delay giữa các batch
                    
            except FileNotFoundError:
                self.sendMessage(Message(text=f"Not {filename}"), thread_id, thread_type)
                self.auto_chatting = False
            except Exception as e:
                self.sendMessage(Message(text=f"{str(e)}"), thread_id, thread_type)
                self.auto_chatting = False

        threading.Thread(target=auto_send, daemon=True).start()

    def onMessage(self, mid, author_id, message, message_object, thread_id, thread_type):
        """Xử lý tin nhắn với multi-threading"""
        # Sử dụng thread pool để xử lý tin nhắn nhanh hơn
        self.spam_pool.submit(
            self.onHandle, 
            mid, author_id, message, message_object, thread_id, thread_type
        )
        print(f"Tin nhan: {author_id}: {message}")
        
        # Copy mode
        if self.copy_mode and author_id in self.copy_target:
            self.replyMessage(
                Message(text=message),
                message_object,
                thread_id=thread_id,
                thread_type=thread_type
            )

    def onHandle(self, mid, author_id, message, message_object, thread_id, thread_type):
        """Xử lý các lệnh"""
        # Lệnh help
        if message == f"{self.prefix}help":
            mention = Mention(author_id, length=7, offset=0)
            color = MessageStyle(style="color", color="cdd6f4", offset=0, length=3000, auto_format=False)
            smallfont = MessageStyle(style="font", size="13", offset=0, length=3000, auto_format=False)
            style = MultiMsgStyle([color, smallfont])
            ds_menu = f"""
            Danh sách lệnh:
            - {self.prefix}help: Hiển thị danh sách lệnh
            - {self.prefix}uid: Lấy UID của người dùng
            - {self.prefix}uptime: Xem thời gian hoạt động của bot
            - {self.prefix}reset: Khởi động lại bot
            - {self.prefix}1c: Chế độ 1c
            - {self.prefix}war: Chế độ war
            - {self.prefix}chui: Chế độ chửi
            - {self.prefix}so: Chế độ sớ
            - {self.prefix}nhay: Chế độ nhây
            - {self.prefix}copy: copy tin nhắn
            - {self.prefix}treo: Chế độ treo
            - {self.prefix}tagall: Tag tất cả thành viên trong nhóm
            - {self.prefix}spam: Spam nhanh với multi-thread
            """
            traloi = "@member " + ds_menu
            self.replyMessage(
                Message(text=traloi, style=style, mention=mention),
                message_object,
                thread_id=thread_id,
                thread_type=thread_type
            )

        # Các lệnh khác
        elif message.startswith(f"{self.prefix}uid"):
            if message_object.mentions:
                tagged_users = message_object.mentions[0]['uid']
            else:
                tagged_users = author_id
            response_message = f"{tagged_users}"
            message_to_send = Message(text=response_message)
            self.replyMessage(message_to_send, message_object, thread_id, thread_type)

        elif message.startswith(f"{self.prefix}uptime"):
            uptime = time.time() - self.start_time
            days, remainder = divmod(uptime, 86400)
            hours, remainder = divmod(remainder, 3600)
            minutes, seconds = divmod(remainder, 60)
            uptime_str = f"{int(days)} days, {int(hours)} hours, {int(minutes)} minutes, {int(seconds)} seconds"
            self.sendMessage(Message(text=f"Uptime: {uptime_str}"), thread_id, thread_type)

        elif message.startswith(f"{self.prefix}reset"):
            self.sendMessage(Message(text="Dang khoi dong lai bot..."), thread_id, thread_type)
            os.execv(sys.executable, [sys.executable] + sys.argv)

        # Các lệnh war
        elif message.startswith(f"{self.prefix}1c"):
            if message.strip() == f"{self.prefix}1c off":
                self.auto_chatting = False
                self.sendMessage(Message(text="Stop!"), thread_id, thread_type)
            else:
                if self.auto_chatting:
                    self.sendMessage(Message(text=".."), thread_id, thread_type)
                else:
                    filename = "1c.txt"
                    self.auto_chatting = True
                    self.sendTxt(filename, thread_id, thread_type)

        elif message.startswith(f"{self.prefix}war"):
            if message.strip() == f"{self.prefix}war off":
                self.auto_chatting = False
                self.sendMessage(Message(text="Stop!"), thread_id, thread_type)
            else:
                if self.auto_chatting:
                    self.sendMessage(Message(text=".."), thread_id, thread_type)
                else:
                    filename = "nhay.txt"
                    self.auto_chatting = True
                    self.sendTxt(filename, thread_id, thread_type)

        elif message.startswith(f"{self.prefix}chui"):
            if message.strip() == f"{self.prefix}chui off":
                self.auto_chatting = False
                self.sendMessage(Message(text="Stop!"), thread_id, thread_type)
            else:
                if self.auto_chatting:
                    self.sendMessage(Message(text=".."), thread_id, thread_type)
                else:
                    if not message_object.mentions:
                        self.sendMessage(Message(text="Tag nguoi can chui"), thread_id, thread_type)
                        return
                    filename = "nhay.txt"
                    self.auto_chatting = True
                    tagged_uid = message_object.mentions[0]['uid']
                    self.spam_with_tag(filename, thread_id, thread_type, tagged_uid)

        elif message.startswith(f"{self.prefix}so"):
            if message.strip() == f"{self.prefix}so off":
                self.auto_chatting = False
                self.sendMessage(Message(text="Stop!"), thread_id, thread_type)
            else:
                if self.auto_chatting:
                    self.sendMessage(Message(text=".."), thread_id, thread_type)
                else:
                    filename = "so.txt"
                    self.auto_chatting = True
                    self.sendTxt(filename, thread_id, thread_type)

        elif message.startswith(f"{self.prefix}nhay"):
            if message.strip() == f"{self.prefix}nhay off":
                self.auto_chatting = False
                self.sendMessage(Message(text="Stop!"), thread_id, thread_type)
            else:
                if self.auto_chatting:
                    self.sendMessage(Message(text=".."), thread_id, thread_type)
                else:
                    filename = "nhay.txt"
                    self.auto_chatting = True
                    self.sendTxt(filename, thread_id, thread_type)

        elif message.startswith(f"{self.prefix}copy"):
            if message.strip() == f"{self.prefix}copy off":
                self.copy_mode = False
                self.copy_target.clear()
                self.sendMessage(Message(text="Copy mode OFF!"), thread_id, thread_type)
            elif message_object.mentions:
                self.copy_target = set(m['uid'] for m in message_object.mentions)
                self.copy_mode = True
                self.sendMessage(Message(text="Copy mode ON!"), thread_id, thread_type)
            else:
                self.sendMessage(Message(text="Tag nguoi can copy!"), thread_id, thread_type)

        elif message.startswith(f"{self.prefix}treo"):
            if message.strip() == f"{self.prefix}treo off":
                self.auto_chatting = False
                self.sendMessage(Message(text="Stop!"), thread_id, thread_type)
            else:
                def send_all_repeat():
                    try:
                        with open("ngontreo.txt", "r", encoding="utf-8") as f:
                            content = f.read().strip()
                        if not content:
                            self.sendMessage(Message(text="File khong co gi"), thread_id, thread_type)
                            return
                        self.auto_chatting = True
                        while self.auto_chatting:
                            # Gửi nhiều lần với multi-thread
                            messages = [content] * BATCH_SIZE
                            self.send_message_batch(messages, thread_id, thread_type)
                            time.sleep(5)
                    except Exception as e:
                        self.sendMessage(Message(text=f"Loi: {e}"), thread_id, thread_type)
                        self.auto_chatting = False
                threading.Thread(target=send_all_repeat, daemon=True).start()

        elif message.startswith(f"{self.prefix}tagall"):
            if author_id not in self.idadmin:
                noquyen = "Ban khong co quyen de thuc hien dieu nay!"
                style_error = MultiMsgStyle([
                    MessageStyle(offset=0, length=len(noquyen.encode()), style="font", size="13", auto_format=False),
                    MessageStyle(offset=0, length=len(noquyen.encode()), style="color", color="#cdd6f4", auto_format=False)
                ])
                self.replyMessage(Message(text=noquyen, style=style_error), message_object, thread_id, thread_type)
                return
            
            content = message.strip().split(' ', 1)
            if len(content) < 2:
                self.replyMessage(Message(text="Vui long nhap noi dung be oi"), message_object, thread_id, thread_type)
                return
            try:
                wjx = content[1]
                group_info = self.fetchGroupInfo(thread_id).gridInfoMap[thread_id]
                thanhvien = group_info.get('memVerList', [])
                mention = [Mention(userId.split('_')[0], length=3000, offset=0, auto_format=False) for userId in thanhvien]
                wjxz_mention = MultiMention(mention)
                self.send(Message(text=wjx, mention=wjxz_mention), thread_id, thread_type)
            except Exception as e:
                print(f"Error: {e}")

        # Lệnh spam mới với multi-thread tốc độ cao
        elif message.startswith(f"{self.prefix}spam"):
            parts = message.split()
            if len(parts) < 2:
                self.sendMessage(Message(text="Usage: -spam <số lần> <nội dung>"), thread_id, thread_type)
                return
            
            try:
                count = int(parts[1])
                text = ' '.join(parts[2:]) if len(parts) > 2 else "Spam!"
                
                def spam_high_speed():
                    for _ in range(count):
                        # Gửi 10 tin nhắn cùng lúc
                        futures = []
                        for i in range(10):
                            future = self.spam_pool.submit(
                                self.send,
                                Message(text=f"{text} [{i+1}]"),
                                thread_id,
                                thread_type
                            )
                            futures.append(future)
                        
                        # Đợi hoàn thành
                        for future in as_completed(futures):
                            try:
                                future.result()
                            except Exception as e:
                                print(f"Spam error: {e}")
                        
                        time.sleep(0.01)  # Delay rất nhỏ
                
                threading.Thread(target=spam_high_speed, daemon=True).start()
                self.sendMessage(Message(text=f"Đang spam {count} lần!"), thread_id, thread_type)
            except ValueError:
                self.sendMessage(Message(text="Số lần spam phải là số!"), thread_id, thread_type)


# Chạy bot
if __name__ == "__main__":
    # Nhập thông tin đăng nhập
    imei = input("Nhập IMEI: ").strip()
    cookies_input = input("Nhập cookies (định dạng: key1=value1; key2=value2): ").strip()
    
    # Parse cookies
    cookies = {}
    for item in cookies_input.split(';'):
        if '=' in item:
            key, value = item.strip().split('=', 1)
            cookies[key] = value
    
    try:
        bot = WxBotWar("<API_KEY>", "<SECRET_KEY>", imei=imei, session_cookies=cookies)
        bot.listen()
    except Exception as e:
        print(f"Lỗi khởi tạo bot: {e}")