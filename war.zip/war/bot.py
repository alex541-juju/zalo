from zlapi import ZaloAPI
from zlapi.models import *
import time
from concurrent.futures import ThreadPoolExecutor
import threading
import os
import sys
import queue

# Replace with your imei and cookies
imei = "cdacc641-6257-418c-9ee1-10961ff411a2-3d96f8e03a42123e5523adf5c57607ad"
cookies = {"zputm_source":"","zputm_medium":"","zputm_campaign":"","zpsrc":"","ZConsent":"timestamp=1787569981557&location=https://zalo.me/ott/","_gid":"GA1.2.1507840943.1787569982","__zi":"3000.SSZzejyD0jydXQckra00a3BBfxQL71AQV8UZjj1O4vvsZQ7-qrqSrNADgVdNNn_MCm.1","__zi-legacy":"3000.SSZzejyD0jydXQckra00a3BBfxQL71AQV8UZjj1O4vvsZQ7-qrqSrNADgVdNNn_MCm.1","_zlang":"vn","app.event.zalo.me":"8028641932241512930","_ga_YT9TMXZYV9":"GS2.1.s1787569934$o1$g1$t1787570918$j60$l0$h0","_ga_YS1V643LGV":"GS2.1.s1787580996$o2$g0$t1787580999$j57$l0$h0","_ga":"GA1.2.500963278.1787569934","_ga_3EM8ZPYYN3":"GS2.2.s1787579667$o2$g1$t1787581002$j60$l0$h0","zpsid":"McFE.408854227.5.dPyt_AIP-TDt1wVBg9dvqz7gY-UKeS7caAlBv0zkgNM0CkSXfSohNywP-TC","zpw_sek":"Ruc4.408854227.a0.NQ1Nt0ZEtWQBkrjhUIK5SoC7O1Xw7oSWR7HiGMveK2SiKou38dDsDH50J3a_63XH9Oxo8_u1hcsg95CXr4y5Sm"}

thread = ThreadPoolExecutor(max_workers=10000)
spam_threads = {}  # Lưu trữ thread cho mỗi nhóm
spam_flags = {}  # Cờ dừng cho mỗi nhóm
print_lock = threading.Lock()
is_spamming = {}  # Trạng thái spam cho từng thread_id

class WxBotWar(ZaloAPI):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.prefix = "-"
        self.idadmin = ["12211212"]
        self.auto_chatting = False
        self.start_time = time.time()
        self.copy_mode = False
        self.copy_target = set()
        self.spam_queue = queue.Queue()

    def sendTxt(self, filename, thread_id, thread_type):
        def auto_send():
            try:
                # Tạo key cho thread
                thread_key = f"{thread_id}_{thread_type}"
                
                # Khởi tạo cờ dừng nếu chưa có
                if thread_key not in spam_flags:
                    spam_flags[thread_key] = False
                
                # Đặt trạng thái spam
                is_spamming[thread_key] = True
                
                with open(filename, "r", encoding="utf-8") as f:
                    lines = [line.strip() for line in f if line.strip()]
                if not lines:
                    self.sendMessage(Message(text="File khong co gi"), thread_id, thread_type)
                    is_spamming[thread_key] = False
                    return

                index = 0
                while not spam_flags.get(thread_key, False):
                    self.sendMessage(Message(text=lines[index]), thread_id, thread_type)
                    index = (index + 1) % len(lines)
                    time.sleep(1)
                
                # Reset khi dừng
                is_spamming[thread_key] = False
                
            except FileNotFoundError:
                self.sendMessage(Message(text=f"Not {filename}"), thread_id, thread_type)
                if thread_key in is_spamming:
                    is_spamming[thread_key] = False
            except Exception as e:
                self.sendMessage(Message(text=f"{str(e)}"), thread_id, thread_type)
                if thread_key in is_spamming:
                    is_spamming[thread_key] = False

        thread_key = f"{thread_id}_{thread_type}"
        # Dừng thread cũ nếu có
        self.stop_spam(thread_key)
        
        # Tạo thread mới
        spam_threads[thread_key] = threading.Thread(target=auto_send)
        spam_threads[thread_key].daemon = True
        spam_threads[thread_key].start()

    def stop_spam(self, thread_key):
        """Dừng spam cho một thread cụ thể"""
        if thread_key in spam_flags:
            spam_flags[thread_key] = True
            time.sleep(0.5)  # Đợi thread dừng
        
        # Reset cờ
        spam_flags[thread_key] = False
        is_spamming[thread_key] = False

    def stop_all_spam(self, thread_id, thread_type):
        """Dừng tất cả spam trong nhóm"""
        thread_key = f"{thread_id}_{thread_type}"
        if thread_key in spam_threads:
            self.stop_spam(thread_key)
            if thread_key in spam_threads:
                del spam_threads[thread_key]

    def stop_all_commands(self, thread_id, thread_type):
        """Dừng tất cả các chế độ đang chạy"""
        thread_key = f"{thread_id}_{thread_type}"
        
        # Dừng spam
        self.stop_all_spam(thread_id, thread_type)
        
        # Dừng copy mode
        self.copy_mode = False
        self.copy_target.clear()
        
        # Reset các cờ khác
        if thread_key in is_spamming:
            is_spamming[thread_key] = False
        if thread_key in spam_flags:
            spam_flags[thread_key] = False
            
        # Gửi thông báo
        self.sendMessage(Message(text="✅ Đã dừng tất cả các chế độ!"), thread_id, thread_type)

    def onMessage(self, mid, author_id, message, message_object, thread_id, thread_type):
        # Tạo key cho thread
        thread_key = f"{thread_id}_{thread_type}"
        
        # In tin nhắn chỉ khi không spam
        with print_lock:
            if not is_spamming.get(thread_key, False):
                print(f"Tin nhan: {author_id}: {message}")
        
        # Submit xử lý
        thread.submit(self.onHandle, mid, author_id, message, message_object, thread_id, thread_type)
        
        # Copy mode
        if self.copy_mode and author_id in self.copy_target:
            self.replyMessage(
                Message(text=message),
                message_object,
                thread_id=thread_id,
                thread_type=thread_type
            )

    def onHandle(self, mid, author_id, message, message_object, thread_id, thread_type):
        thread_key = f"{thread_id}_{thread_type}"
        
        # Lệnh stop - dừng tất cả
        if message == f"{self.prefix}stop":
            self.stop_all_commands(thread_id, thread_type)
            return
        
        # Lệnh help với tag tên
        if message == f"{self.prefix}help":
            # Tạo mention cho người gửi
            mention = Mention(author_id, length=len(author_id), offset=0)
            
            # Nội dung menu
            menu_text = f"""╔══════════════════════════════╗
║      📋 DANH SÁCH LỆNH      ║
╠══════════════════════════════╣
║ {self.prefix}help   - Hiển thị menu  ║
║ {self.prefix}uid    - Lấy UID user   ║
║ {self.prefix}uptime - Thời gian bot  ║
║ {self.prefix}reset  - Reset bot      ║
║ {self.prefix}stop   - Dừng tất cả    ║
╠══════════════════════════════╣
║ 📌 CHẾ ĐỘ SPAM:             ║
║ {self.prefix}1c     - Spam 1 câu     ║
║ {self.prefix}war    - Spam war       ║
║ {self.prefix}chui   - Spam chửi      ║
║ {self.prefix}so     - Spam sớ        ║
║ {self.prefix}nhay   - Spam nhây      ║
║ {self.prefix}treo   - Treo tin nhắn  ║
║ {self.prefix}tagtreo- Treo + tag all ║
║ {self.prefix}copy   - Copy tin nhắn  ║
║ {self.prefix}tagall - Tag tất cả     ║
╠══════════════════════════════╣
║ 🔄 TẮT CHẾ ĐỘ:             ║
║ {self.prefix}* off  - Tắt chế độ    ║
╚══════════════════════════════╝

💡 Ví dụ: {self.prefix}war để bắt đầu
💡 {self.prefix}war off để dừng
💡 {self.prefix}stop để dừng tất cả"""

            # Gửi tin nhắn với mention
            self.replyMessage(
                Message(text=menu_text, mention=mention),
                message_object,
                thread_id=thread_id,
                thread_type=thread_type
            )
            return

        elif message.startswith(f"{self.prefix}uid"):
            if message_object.mentions:
                tagged_users = message_object.mentions[0]['uid']
            else:
                tagged_users = author_id
            response_message = f"UID: {tagged_users}"
            message_to_send = Message(text=response_message)
            self.replyMessage(message_to_send, message_object, thread_id, thread_type)

        elif message.startswith(f"{self.prefix}uptime"):
            uptime = time.time() - self.start_time
            days, remainder = divmod(uptime, 86400)
            hours, remainder = divmod(remainder, 3600)
            minutes, seconds = divmod(remainder, 60)
            uptime_str = f"{int(days)} ngày, {int(hours)} giờ, {int(minutes)} phút, {int(seconds)} giây"
            self.sendMessage(Message(text=f"⏰ Uptime: {uptime_str}"), thread_id, thread_type)
        
        elif message.startswith(f"{self.prefix}reset"):
            self.sendMessage(Message(text="🔄 Đang khởi động lại bot..."), thread_id, thread_type)
            os.execv(sys.executable, [sys.executable] + sys.argv)

        # Lệnh war
        elif message.startswith(f"{self.prefix}1c"):
            if message.strip() == f"{self.prefix}1c off":
                self.stop_all_spam(thread_id, thread_type)
                self.sendMessage(Message(text="⏹️ Đã dừng spam 1c!"), thread_id, thread_type)
            else:
                if is_spamming.get(thread_key, False):
                    self.sendMessage(Message(text="⚠️ Đang spam rồi! Dùng lệnh off để dừng."), thread_id, thread_type)
                else:
                    filename = "1c.txt"
                    self.sendTxt(filename, thread_id, thread_type)
                    self.sendMessage(Message(text="▶️ Bắt đầu spam 1c!"), thread_id, thread_type)

        elif message.startswith(f"{self.prefix}war"):
            if message.strip() == f"{self.prefix}war off":
                self.stop_all_spam(thread_id, thread_type)
                self.sendMessage(Message(text="⏹️ Đã dừng spam war!"), thread_id, thread_type)
            else:
                if is_spamming.get(thread_key, False):
                    self.sendMessage(Message(text="⚠️ Đang spam rồi! Dùng lệnh off để dừng."), thread_id, thread_type)
                else:
                    filename = "nhay.txt"
                    self.sendTxt(filename, thread_id, thread_type)
                    self.sendMessage(Message(text="▶️ Bắt đầu spam war!"), thread_id, thread_type)

        elif message.startswith(f"{self.prefix}chui"):
            if message.strip() == f"{self.prefix}chui off":
                self.stop_all_spam(thread_id, thread_type)
                self.sendMessage(Message(text="⏹️ Đã dừng spam chửi!"), thread_id, thread_type)
            else:
                if is_spamming.get(thread_key, False):
                    self.sendMessage(Message(text="⚠️ Đang spam rồi! Dùng lệnh off để dừng."), thread_id, thread_type)
                else:
                    if not message_object.mentions:
                        self.sendMessage(Message(text="❌ Tag người cần chửi!"), thread_id, thread_type)
                        return

                    filename = "nhay.txt"
                    spam_flags[thread_key] = False
                    is_spamming[thread_key] = True

                    def send_tagged():
                        try:
                            with open(filename, "r", encoding="utf-8") as f:
                                lines = [line.strip() for line in f if line.strip()]
                            if not lines:
                                self.sendMessage(Message(text="❌ File không có gì"), thread_id, thread_type)
                                is_spamming[thread_key] = False
                                return
                            tagged_uid = message_object.mentions[0]['uid']
                            index = 0
                            while not spam_flags.get(thread_key, False):
                                traloi = lines[index] + " @member"
                                offset = len(lines[index]) + 1
                                mention = Mention(tagged_uid, offset=offset, length=8)
                                self.send(
                                    Message(text=traloi, mention=mention),
                                    thread_id,
                                    thread_type
                                )
                                index = (index + 1) % len(lines)
                                time.sleep(0.5)
                            is_spamming[thread_key] = False
                        except FileNotFoundError:
                            self.sendMessage(Message(text=f"❌ Không tìm thấy file {filename}"), thread_id, thread_type)
                            is_spamming[thread_key] = False
                        except Exception as e:
                            self.sendMessage(Message(text=f"❌ Lỗi: {str(e)}"), thread_id, thread_type)
                            is_spamming[thread_key] = False

                    self.stop_spam(thread_key)
                    spam_threads[thread_key] = threading.Thread(target=send_tagged)
                    spam_threads[thread_key].daemon = True
                    spam_threads[thread_key].start()
                    self.sendMessage(Message(text="▶️ Bắt đầu spam chửi!"), thread_id, thread_type)

        elif message.startswith(f"{self.prefix}so"):
            if message.strip() == f"{self.prefix}so off":
                self.stop_all_spam(thread_id, thread_type)
                self.sendMessage(Message(text="⏹️ Đã dừng spam sớ!"), thread_id, thread_type)
            else:
                if is_spamming.get(thread_key, False):
                    self.sendMessage(Message(text="⚠️ Đang spam rồi! Dùng lệnh off để dừng."), thread_id, thread_type)
                else:
                    filename = "so.txt"
                    self.sendTxt(filename, thread_id, thread_type)
                    self.sendMessage(Message(text="▶️ Bắt đầu spam sớ!"), thread_id, thread_type)

        elif message.startswith(f"{self.prefix}nhay"):
            if message.strip() == f"{self.prefix}nhay off":
                self.stop_all_spam(thread_id, thread_type)
                self.sendMessage(Message(text="⏹️ Đã dừng spam nhây!"), thread_id, thread_type)
            else:
                if is_spamming.get(thread_key, False):
                    self.sendMessage(Message(text="⚠️ Đang spam rồi! Dùng lệnh off để dừng."), thread_id, thread_type)
                else:
                    filename = "nhay.txt"
                    self.sendTxt(filename, thread_id, thread_type)
                    self.sendMessage(Message(text="▶️ Bắt đầu spam nhây!"), thread_id, thread_type)
        
        elif message.startswith(f"{self.prefix}copy"):
            if message.strip() == f"{self.prefix}copy off":
                self.copy_mode = False
                self.copy_target.clear()
                self.sendMessage(Message(text="⏹️ Copy mode OFF!"), thread_id, thread_type)
            elif message_object.mentions:
                self.copy_target = set(m['uid'] for m in message_object.mentions)
                self.copy_mode = True
                self.sendMessage(Message(text="✅ Copy mode ON!"), thread_id, thread_type)
            else:
                self.sendMessage(Message(text="❌ Tag người cần copy!"), thread_id, thread_type)

        # Lệnh treo thường (không tag)
        elif message.startswith(f"{self.prefix}treo"):
            if message.strip() == f"{self.prefix}treo off":
                self.stop_all_spam(thread_id, thread_type)
                self.sendMessage(Message(text="⏹️ Đã dừng treo!"), thread_id, thread_type)
            else:
                if is_spamming.get(thread_key, False):
                    self.sendMessage(Message(text="⚠️ Đang spam rồi! Dùng lệnh off để dừng."), thread_id, thread_type)
                else:
                    # Kiểm tra nếu có nội dung riêng
                    parts = message.strip().split(' ', 1)
                    if len(parts) > 1:
                        custom_content = parts[1]
                        spam_flags[thread_key] = False
                        is_spamming[thread_key] = True
                        
                        def send_custom_repeat():
                            try:
                                while not spam_flags.get(thread_key, False):
                                    self.sendMessage(Message(text=custom_content), thread_id, thread_type)
                                    time.sleep(5)
                                is_spamming[thread_key] = False
                            except Exception as e:
                                self.sendMessage(Message(text=f"❌ Lỗi: {e}"), thread_id, thread_type)
                                is_spamming[thread_key] = False
                        
                        self.stop_spam(thread_key)
                        spam_threads[thread_key] = threading.Thread(target=send_custom_repeat)
                        spam_threads[thread_key].daemon = True
                        spam_threads[thread_key].start()
                        self.sendMessage(Message(text=f"▶️ Bắt đầu treo: {custom_content}"), thread_id, thread_type)
                    else:
                        # Treo từ file
                        spam_flags[thread_key] = False
                        is_spamming[thread_key] = True
                        
                        def send_all_repeat():
                            try:
                                with open("ngontreo.txt", "r", encoding="utf-8") as f:
                                    content = f.read().strip()
                                if not content:
                                    self.sendMessage(Message(text="❌ File khong co gi"), thread_id, thread_type)
                                    is_spamming[thread_key] = False
                                    return
                                while not spam_flags.get(thread_key, False):
                                    self.sendMessage(Message(text=content), thread_id, thread_type)
                                    time.sleep(5)
                                is_spamming[thread_key] = False
                            except Exception as e:
                                self.sendMessage(Message(text=f"❌ Lỗi: {e}"), thread_id, thread_type)
                                is_spamming[thread_key] = False
                        
                        self.stop_spam(thread_key)
                        spam_threads[thread_key] = threading.Thread(target=send_all_repeat)
                        spam_threads[thread_key].daemon = True
                        spam_threads[thread_key].start()
                        self.sendMessage(Message(text="▶️ Bắt đầu treo từ file!"), thread_id, thread_type)

        # Lệnh treo + tag all
        elif message.startswith(f"{self.prefix}tagtreo"):
            if message.strip() == f"{self.prefix}tagtreo off":
                self.stop_all_spam(thread_id, thread_type)
                self.sendMessage(Message(text="⏹️ Đã dừng tagtreo!"), thread_id, thread_type)
            else:
                if is_spamming.get(thread_key, False):
                    self.sendMessage(Message(text="⚠️ Đang spam rồi! Dùng lệnh off để dừng."), thread_id, thread_type)
                else:
                    # Kiểm tra nội dung tùy chỉnh
                    parts = message.strip().split(' ', 1)
                    custom_content = None
                    if len(parts) > 1:
                        custom_content = parts[1]
                    
                    spam_flags[thread_key] = False
                    is_spamming[thread_key] = True
                    
                    def send_treo_with_tagall():
                        try:
                            # Lấy danh sách thành viên
                            group_info = self.fetchGroupInfo(thread_id).gridInfoMap[thread_id]
                            thanhvien = group_info.get('memVerList', [])
                            
                            # Tạo mention cho tất cả
                            mention = [Mention(userId.split('_')[0], length=3000, offset=0, auto_format=False) for userId in thanhvien]
                            wjxz_mention = MultiMention(mention)
                            
                            # Lấy nội dung
                            if custom_content:
                                content = custom_content
                            else:
                                with open("ngontreo.txt", "r", encoding="utf-8") as f:
                                    content = f.read().strip()
                                if not content:
                                    self.sendMessage(Message(text="❌ File khong co gi"), thread_id, thread_type)
                                    is_spamming[thread_key] = False
                                    return
                            
                            # Gửi tin nhắn với tag all
                            while not spam_flags.get(thread_key, False):
                                self.send(
                                    Message(text=content, mention=wjxz_mention),
                                    thread_id,
                                    thread_type
                                )
                                time.sleep(3)  # Thời gian giữa các lần gửi
                            
                            is_spamming[thread_key] = False
                        except Exception as e:
                            self.sendMessage(Message(text=f"❌ Lỗi: {e}"), thread_id, thread_type)
                            is_spamming[thread_key] = False
                    
                    self.stop_spam(thread_key)
                    spam_threads[thread_key] = threading.Thread(target=send_treo_with_tagall)
                    spam_threads[thread_key].daemon = True
                    spam_threads[thread_key].start()
                    
                    if custom_content:
                        self.sendMessage(Message(text=f"▶️ Bắt đầu tagtreo: {custom_content}"), thread_id, thread_type)
                    else:
                        self.sendMessage(Message(text="▶️ Bắt đầu tagtreo từ file!"), thread_id, thread_type)

        # Giữ lệnh xbdz cũ (tag all + treo từ file)
        elif message.startswith(f"{self.prefix}xbdz"):
            if message.strip() == f"{self.prefix}xbdz off":
                self.stop_all_spam(thread_id, thread_type)
                self.sendMessage(Message(text="⏹️ Đã dừng xbdz!"), thread_id, thread_type)
            else:
                if is_spamming.get(thread_key, False):
                    self.sendMessage(Message(text="⚠️ Đang spam rồi! Dùng lệnh off để dừng."), thread_id, thread_type)
                else:
                    # Kiểm tra nội dung tùy chỉnh
                    parts = message.strip().split(' ', 1)
                    custom_content = None
                    if len(parts) > 1:
                        custom_content = parts[1]
                    
                    spam_flags[thread_key] = False
                    is_spamming[thread_key] = True
                    
                    def send_treotagall():
                        try:
                            # Lấy danh sách thành viên
                            group_info = self.fetchGroupInfo(thread_id).gridInfoMap[thread_id]
                            thanhvien = group_info.get('memVerList', [])
                            
                            # Tạo mention cho tất cả
                            mention = [Mention(userId.split('_')[0], length=3000, offset=0, auto_format=False) for userId in thanhvien]
                            wjxz_mention = MultiMention(mention)
                            
                            # Lấy nội dung
                            if custom_content:
                                content = custom_content
                            else:
                                with open("ngontreo.txt", "r", encoding="utf-8") as f:
                                    content = f.read().strip()
                                if not content:
                                    self.sendMessage(Message(text="❌ File khong co gi"), thread_id, thread_type)
                                    is_spamming[thread_key] = False
                                    return
                            
                            # Gửi tin nhắn với tag all
                            while not spam_flags.get(thread_key, False):
                                self.send(
                                    Message(text=content, mention=wjxz_mention),
                                    thread_id,
                                    thread_type
                                )
                                time.sleep(1)  # Thời gian giữa các lần gửi
                            
                            is_spamming[thread_key] = False
                        except Exception as e:
                            self.sendMessage(Message(text=f"❌ Lỗi: {e}"), thread_id, thread_type)
                            is_spamming[thread_key] = False
                    
                    self.stop_spam(thread_key)
                    spam_threads[thread_key] = threading.Thread(target=send_treotagall)
                    spam_threads[thread_key].daemon = True
                    spam_threads[thread_key].start()
                    
                    if custom_content:
                        self.sendMessage(Message(text=f"▶️ Bắt đầu xbdz: {custom_content}"), thread_id, thread_type)
                    else:
                        self.sendMessage(Message(text="▶️ Bắt đầu xbdz từ file!"), thread_id, thread_type)

        elif message.startswith(f"{self.prefix}tagall"):
            if author_id not in self.idadmin:
                noquyen = "❌ Bạn không có quyền để thực hiện điều này!"
                style_error = MultiMsgStyle([
                    MessageStyle(offset=0, length=len(noquyen.encode()), style="font", size="13", auto_format=False),
                    MessageStyle(offset=0, length=len(noquyen.encode()), style="color", color="#ff6b6b", auto_format=False)
                ])
                self.replyMessage(Message(text=noquyen, style=style_error), message_object, thread_id, thread_type)
                return
            content = message.strip().split(' ', 1)
            if len(content) < 2:
                self.replyMessage(Message(text="❌ Vui lòng nhập nội dung!"), message_object, thread_id, thread_type)
                return
            try:
                wjx = content[1]
                group_info = self.fetchGroupInfo(thread_id).gridInfoMap[thread_id]
                thanhvien = group_info.get('memVerList', [])
                mention = [Mention(userId.split('_')[0], length=3000, offset=0, auto_format=False) for userId in thanhvien]
                wjxz_mention = MultiMention(mention)
                self.send(Message(text=wjx, mention=wjxz_mention), thread_id, thread_type)
            except Exception as e:
                print(f"Error: {e}")

bot = WxBotWar("<API_KEY>", "<SECRET_KEY>", imei=imei, session_cookies=cookies)
bot.listen()