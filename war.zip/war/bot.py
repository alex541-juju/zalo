from zlapi import ZaloAPI
from zlapi.models import *
import time
from concurrent.futures import ThreadPoolExecutor
import threading
import os
import sys
import random

# Replace with your imei and cookies
imei = "cdacc641-6257-418c-9ee1-10961ff411a2-3d96f8e03a42123e5523adf5c57607ad"
cookies = {"zputm_source":"","zputm_medium":"","zputm_campaign":"","zpsrc":"","ZConsent":"timestamp=1787569981557&location=https://zalo.me/ott/","_gid":"GA1.2.1507840943.1787569982","__zi":"3000.SSZzejyD0jydXQckra00a3BBfxQL71AQV8UZjj1O4vvsZQ7-qrqSrNADgVdNNn_MCm.1","__zi-legacy":"3000.SSZzejyD0jydXQckra00a3BBfxQL71AQV8UZjj1O4vvsZQ7-qrqSrNADgVdNNn_MCm.1","_zlang":"vn","app.event.zalo.me":"8028641932241512930","_ga_YT9TMXZYV9":"GS2.1.s1787569934$o1$g1$t1787570918$j60$l0$h0","_ga_YS1V643LGV":"GS2.1.s1787570957$o1$g0$t1787570958$j59$l0$h0","_ga":"GA1.2.500963278.1787569934","_ga_3EM8ZPYYN3":"GS2.2.s1787569982$o1$g1$t1787570962$j60$l0$h0","zpsid":"Hcih.408854227.3._DkiUML2E0Yst6OGQK8u210nIZnLUW0zKN0AFywrQAv1wIRwP5yJX0z2E0W","zpw_sek":"CB0c.408854227.a0.AE902IXW_gYh5lN5MOibtGEfGBPQiGUJ5iPtd2ZZG9Gy_N-q8CqEiZFPJOqvjXZ_1I3IZTwlZiEAYZZszE4btG"}

thread = ThreadPoolExecutor(max_workers=20)  # Giới hạn workers để tránh bị block

class WxBotWar(ZaloAPI):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.prefix = "-"
        self.idadmin = ["363636"] #adm id
        self.auto_chatting = False
        self.start_time = time.time()
        self.copy_mode = False
        self.copy_target = set()
        self.spam_threads = []  # Lưu các thread spam

    def sendTxt(self, filename, thread_id, thread_type, speed=1, concurrent=3):
        """Gửi tin nhắn với tốc độ cao hơn"""
        def auto_send():
            try:
                with open(filename, "r", encoding="utf-8") as f:
                    lines = [line.strip() for line in f if line.strip()]
                if not lines:
                    self.sendMessage(Message(text="File khong co gi"), thread_id, thread_type)
                    self.auto_chatting = False
                    return

                def send_worker():
                    index = 0
                    while self.auto_chatting:
                        try:
                            self.sendMessage(Message(text=lines[index % len(lines)]), thread_id, thread_type)
                            index += 1
                            time.sleep(speed / concurrent)  # Chia tốc độ cho số worker
                        except Exception as e:
                            print(f"Send error: {e}")
                            time.sleep(0.5)

                # Tạo nhiều thread để gửi song song
                workers = []
                for _ in range(concurrent):
                    t = threading.Thread(target=send_worker)
                    t.daemon = True
                    t.start()
                    workers.append(t)
                    time.sleep(0.1)  # Delay nhẹ khi start

                # Đợi các thread kết thúc (thực tế sẽ chạy vô hạn)
                for t in workers:
                    t.join()

            except FileNotFoundError:
                self.sendMessage(Message(text=f"Not {filename}"), thread_id, thread_type)
                self.auto_chatting = False
            except Exception as e:
                self.sendMessage(Message(text=f"{str(e)}"), thread_id, thread_type)
                self.auto_chatting = False

        threading.Thread(target=auto_send, daemon=True).start()

    def onMessage(self, mid, author_id, message, message_object, thread_id, thread_type):
        thread.submit(self.onHandle, mid, author_id, message, message_object, thread_id, thread_type)
        print(f"Tin nhan: {author_id}: {message}")
        
        # Copy mode:
        if self.copy_mode and author_id in self.copy_target:
            self.replyMessage(
                Message(text=message),
                message_object,
                thread_id=thread_id,
                thread_type=thread_type
            )

    def onHandle(self, mid, author_id, message, message_object, thread_id, thread_type):
        # Lệnh chức năng
        if message == f"{self.prefix}help":
            mention = Mention(author_id, length=7, offset=0)
            color = MessageStyle(style="color", color="cdd6f4", offset=0, length=3000, auto_format=False)
            smallfont = MessageStyle(style="font", size="13", offset=0, length=3000, auto_format=False)
            style = MultiMsgStyle([color, smallfont])
            ds_menu = """
            Danh sách lệnh:
            - {self.prefix}help: Hiển thị danh sách lệnh
            - {self.prefix}uid: Lấy UID của người dùng
            - {self.prefix}uptime: Xem thời gian hoạt động của bot
            - {self.prefix}reset: Khởi động lại bot
            - {self.prefix}1c: Chế độ 1c
            - {self.prefix}war: Chế độ war
            - {self.prefix}chui: Chế độ chửi
            - {self.prefix}so: Chế độ sớ
            - {self.prefix}nhay: Chế độ nhây
            - {self.prefix}copy: copy tin nhắn
            - {self.prefix}treo: Chế độ treo
            - {self.prefix}tagall: Tag tất cả thành viên trong nhóm
            - {self.prefix}speed [1-10]: Đặt tốc độ spam (mặc định 3)
            - {self.prefix}concurrent [1-10]: Đặt số luồng spam (mặc định 3)

            """
            traloi = "@member "
            self.replyMessage(
                Message(text=traloi, style=style, mention=mention),
                message_object,
                thread_id=thread_id,
                thread_type=thread_type
            )

        elif message.startswith(f"{self.prefix}uid"):
            if message_object.mentions:
                tagged_users = message_object.mentions[0]['uid']
            else:
                tagged_users = author_id
            response_message = f"{tagged_users}"
            message_to_send = Message(text=response_message)
            self.replyMessage(message_to_send, message_object, thread_id, thread_type)

        elif message.startswith(f"{self.prefix}uptime"):
            uptime = time.time() - self.start_time
            days, remainder = divmod(uptime, 86400)
            hours, remainder = divmod(remainder, 3600)
            minutes, seconds = divmod(remainder, 60)
            uptime_str = f"{int(days)} days, {int(hours)} hours, {int(minutes)} minutes, {int(seconds)} seconds"
            self.sendMessage(Message(text=f"Uptime: {uptime_str}"), thread_id, thread_type)
        
        elif message.startswith(f"{self.prefix}reset"):
            self.sendMessage(Message(text="Đang khởi động lại bot..."), thread_id, thread_type)
            os.execv(sys.executable, [sys.executable] + sys.argv)

        # Lệnh war với tốc độ cao
        elif message.startswith(f"{self.prefix}1c"):
            if message.strip() == f"{self.prefix}1c off":
                self.auto_chatting = False
                self.sendMessage(Message(text="Stop!"), thread_id, thread_type)
            else:
                if self.auto_chatting:
                    self.sendMessage(Message(text=".."), thread_id, thread_type)
                else:
                    filename = "1c.txt" 
                    self.auto_chatting = True
                    self.sendTxt(filename, thread_id, thread_type, speed=0.5, concurrent=5)

        elif message.startswith(f"{self.prefix}war"):
            if message.strip() == f"{self.prefix}war off":
                self.auto_chatting = False
                self.sendMessage(Message(text="Stop!"), thread_id, thread_type)
            else:
                if self.auto_chatting:
                    self.sendMessage(Message(text=".."), thread_id, thread_type)
                else:
                    filename = "nhay.txt"
                    self.auto_chatting = True
                    self.sendTxt(filename, thread_id, thread_type, speed=0.3, concurrent=8)

        elif message.startswith(f"{self.prefix}chui"):
            if message.strip() == f"{self.prefix}chui off":
                self.auto_chatting = False
                self.sendMessage(Message(text="Stop!"), thread_id, thread_type)
            else:
                if self.auto_chatting:
                    self.sendMessage(Message(text=".."), thread_id, thread_type)
                else:
                    if not message_object.mentions:
                        self.sendMessage(Message(text="Tag người cần chửi"), thread_id, thread_type)
                        return

                    filename = "nhay.txt"
                    self.auto_chatting = True

                    def send_tagged():
                        try:
                            with open(filename, "r", encoding="utf-8") as f:
                                lines = [line.strip() for line in f if line.strip()]
                            if not lines:
                                self.sendMessage(Message(text="File không có gì"), thread_id, thread_type)
                                self.auto_chatting = False
                                return
                            tagged_uid = message_object.mentions[0]['uid']
                            
                            def tag_worker():
                                index = 0
                                while self.auto_chatting:
                                    try:
                                        traloi = lines[index % len(lines)] + " @member"
                                        offset = len(lines[index % len(lines)]) + 1
                                        mention = Mention(tagged_uid, offset=offset, length=8)
                                        self.send(
                                            Message(text=traloi, mention=mention),
                                            thread_id,
                                            thread_type
                                        )
                                        index += 1
                                        time.sleep(0.2)  # Gửi nhanh hơn
                                    except Exception as e:
                                        print(f"Tag send error: {e}")
                                        time.sleep(0.5)
                            
                            # Tạo nhiều thread tag
                            workers = []
                            for _ in range(3):
                                t = threading.Thread(target=tag_worker)
                                t.daemon = True
                                t.start()
                                workers.append(t)
                            
                            for t in workers:
                                t.join()
                                
                        except FileNotFoundError:
                            self.sendMessage(Message(text=f"Không tìm thấy file {filename}"), thread_id, thread_type)
                            self.auto_chatting = False
                        except Exception as e:
                            self.sendMessage(Message(text=f"Lỗi: {str(e)}"), thread_id, thread_type)
                            self.auto_chatting = False

                    threading.Thread(target=send_tagged, daemon=True).start()

        elif message.startswith(f"{self.prefix}so"):
            if message.strip() == f"{self.prefix}so off":
                self.auto_chatting = False
                self.sendMessage(Message(text="Stop!"), thread_id, thread_type)
            else:
                if self.auto_chatting:
                    self.sendMessage(Message(text=".."), thread_id, thread_type)
                else:
                    filename = "so.txt" 
                    self.auto_chatting = True
                    self.sendTxt(filename, thread_id, thread_type, speed=0.5, concurrent=5)

        elif message.startswith(f"{self.prefix}nhay"):
            if message.strip() == f"{self.prefix}nhay off":
                self.auto_chatting = False
                self.sendMessage(Message(text="Stop!"), thread_id, thread_type)
            else:
                if self.auto_chatting:
                    self.sendMessage(Message(text=".."), thread_id, thread_type)
                else:
                    filename = "nhay.txt" 
                    self.auto_chatting = True
                    self.sendTxt(filename, thread_id, thread_type, speed=0.2, concurrent=10)  # Spam cực nhanh
        
        elif message.startswith(f"{self.prefix}copy"):
            if message.strip() == f"{self.prefix}copy off":
                self.copy_mode = False
                self.copy_target.clear()
                self.sendMessage(Message(text="Copy mode OFF!"), thread_id, thread_type)
            elif message_object.mentions:
                self.copy_target = set(m['uid'] for m in message_object.mentions)
                self.copy_mode = True
                self.sendMessage(Message(text="Copy mode ON!"), thread_id, thread_type)
            else:
                self.sendMessage(Message(text="Tag người cần copy!"), thread_id, thread_type)

        elif message.startswith(f"{self.prefix}treo"):
            if message.strip() == f"{self.prefix}treo off":
                self.auto_chatting = False
                self.sendMessage(Message(text="Stop!"), thread_id, thread_type)
            else:
                def send_all_repeat():
                    try:
                        with open("ngontreo.txt", "r", encoding="utf-8") as f:
                            content = f.read().strip()
                        if not content:
                            self.sendMessage(Message(text="File khong co gi"), thread_id, thread_type)
                            return
                        self.auto_chatting = True
                        
                        def repeat_worker():
                            while self.auto_chatting:
                                try:
                                    self.sendMessage(Message(text=content), thread_id, thread_type)
                                    time.sleep(1)  # Tăng tốc độ
                                except Exception as e:
                                    print(f"Repeat error: {e}")
                                    time.sleep(0.5)
                        
                        # Tạo 5 thread để treo
                        workers = []
                        for _ in range(3):
                            t = threading.Thread(target=repeat_worker)
                            t.daemon = True
                            t.start()
                            workers.append(t)
                        
                        for t in workers:
                            t.join()
                            
                    except Exception as e:
                        self.sendMessage(Message(text=f"Lỗi: {e}"), thread_id, thread_type)
                        self.auto_chatting = False
                threading.Thread(target=send_all_repeat, daemon=True).start()

        elif message.startswith(f"{self.prefix}xbdz"):
            if message.strip() == f"{self.prefix}xbdz off":
                self.auto_chatting = False
                self.sendMessage(Message(text="Stop!"), thread_id, thread_type)
            else:
                def send_treotagall():
                    try:
                        with open("ngontreo.txt", "r", encoding="utf-8") as f:
                            content = f.read().strip()
                        if not content:
                            self.sendMessage(Message(text="File khong co gi"), thread_id, thread_type)
                            return
                        self.auto_chatting = True
                        group_info = self.fetchGroupInfo(thread_id).gridInfoMap[thread_id]
                        thanhvien = group_info.get('memVerList', [])
                        mention = [Mention(userId.split('_')[0], length=3000, offset=0, auto_format=False) for userId in thanhvien]
                        wjxz_mention = MultiMention(mention)
                        
                        def tagall_worker():
                            while self.auto_chatting:
                                try:
                                    self.send(Message(text=content, mention=wjxz_mention), thread_id, thread_type)
                                    time.sleep(0.5)  # Tăng tốc
                                except Exception as e:
                                    print(f"Tagall error: {e}")
                                    time.sleep(0.5)
                        
                        # Tạo 3 thread để tagall
                        workers = []
                        for _ in range(3):
                            t = threading.Thread(target=tagall_worker)
                            t.daemon = True
                            t.start()
                            workers.append(t)
                        
                        for t in workers:
                            t.join()
                            
                    except Exception as e:
                        self.sendMessage(Message(text=f"Lỗi: {e}"), thread_id, thread_type)
                        self.auto_chatting = False
                threading.Thread(target=send_treotagall, daemon=True).start()

        elif message.startswith(f"{self.prefix}tagall"):
            if author_id not in self.idadmin:
                noquyen = "Bạn không có quyền để thực hiện điều này!"
                style_error = MultiMsgStyle([
                    MessageStyle(offset=0, length=len(noquyen.encode()), style="font", size="13", auto_format=False),
                    MessageStyle(offset=0, length=len(noquyen.encode()), style="color", color="#cdd6f4", auto_format=False)
                ])
                self.replyMessage(Message(text=noquyen, style=style_error), message_object, thread_id, thread_type)
                return
            content = message.strip().split(' ', 1)
            if len(content) < 2:
                self.replyMessage(Message(text="Vui lòng nhập nội dung bé ơi"), message_object, thread_id, thread_type)
                return
            try:
                wjx = content[1]
                group_info = self.fetchGroupInfo(thread_id).gridInfoMap[thread_id]
                thanhvien = group_info.get('memVerList', [])
                mention = [Mention(userId.split('_')[0], length=3000, offset=0, auto_format=False) for userId in thanhvien]
                wjxz_mention = MultiMention(mention)
                self.send(Message(text=wjx, mention=wjxz_mention), thread_id, thread_type)
            except Exception as e:
                print(f"Error: {e}")

        # Lệnh điều chỉnh tốc độ
        elif message.startswith(f"{self.prefix}speed"):
            try:
                speed = int(message.split(' ')[1])
                if 1 <= speed <= 10:
                    self.sendMessage(Message(text=f"Đã đặt tốc độ spam thành {speed}"), thread_id, thread_type)
                else:
                    self.sendMessage(Message(text="Vui lòng chọn speed từ 1-10"), thread_id, thread_type)
            except:
                self.sendMessage(Message(text="Sai cú pháp! Dùng: -speed [1-10]"), thread_id, thread_type)

        elif message.startswith(f"{self.prefix}concurrent"):
            try:
                concurrent = int(message.split(' ')[1])
                if 1 <= concurrent <= 10:
                    self.sendMessage(Message(text=f"Đã đặt số luồng spam thành {concurrent}"), thread_id, thread_type)
                else:
                    self.sendMessage(Message(text="Vui lòng chọn concurrent từ 1-10"), thread_id, thread_type)
            except:
                self.sendMessage(Message(text="Sai cú pháp! Dùng: -concurrent [1-10]"), thread_id, thread_type)

bot = WxBotWar("<API_KEY>", "<SECRET_KEY>", imei=imei, session_cookies=cookies)
bot.listen()