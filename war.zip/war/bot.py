from zlapi import ZaloAPI
from zlapi.models import *
import time
from concurrent.futures import ThreadPoolExecutor
import threading
import os
import sys
import queue
import signal

# Replace with your imei and cookies
imei = "cdacc641-6257-418c-9ee1-10961ff411a2-3d96f8e03a42123e5523adf5c57607ad"
cookies = {"zputm_source":"","zputm_medium":"","zputm_campaign":"","zpsrc":"","ZConsent":"timestamp=1787569981557&location=https://zalo.me/ott/","_gid":"GA1.2.1507840943.1787569982","__zi":"3000.SSZzejyD0jydXQckra00a3BBfxQL71AQV8UZjj1O4vvsZQ7-qrqSrNADgVdNNn_MCm.1","__zi-legacy":"3000.SSZzejyD0jydXQckra00a3BBfxQL71AQV8UZjj1O4vvsZQ7-qrqSrNADgVdNNn_MCm.1","_zlang":"vn","app.event.zalo.me":"8028641932241512930","_ga_YT9TMXZYV9":"GS2.1.s1787569934$o1$g1$t1787570918$j60$l0$h0","_ga_YS1V643LGV":"GS2.1.s1787580996$o2$g0$t1787580999$j57$l0$h0","_ga":"GA1.2.500963278.1787569934","_ga_3EM8ZPYYN3":"GS2.2.s1787579667$o2$g1$t1787581002$j60$l0$h0","zpsid":"McFE.408854227.5.dPyt_AIP-TDt1wVBg9dvqz7gY-UKeS7caAlBv0zkgNM0CkSXfSohNywP-TC","zpw_sek":"Ruc4.408854227.a0.NQ1Nt0ZEtWQBkrjhUIK5SoC7O1Xw7oSWR7HiGMveK2SiKou38dDsDH50J3a_63XH9Oxo8_u1hcsg95CXr4y5Sm"}

thread = ThreadPoolExecutor(max_workers=10000)

class WxBotWar(ZaloAPI):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.prefix = "-"
        self.idadmin = ["12211212"]
        self.auto_chatting = False
        self.start_time = time.time()
        self.copy_mode = False
        self.copy_target = set()
        self.thread_pool = ThreadPoolExecutor(max_workers=20)
        self.send_queue = queue.Queue()
        self.workers = []
        self.max_workers = 10
        self.stop_event = threading.Event()
        self.active_threads = []
        
        # ID duy nhất được phép tương tác với bot
        self.allowed_user_id = "835355022821204140"
        
    def stop_all_threads(self):
        """Dừng tất cả threads và workers"""
        print("Đang dừng tất cả threads...")
        
        self.auto_chatting = False
        self.stop_event.set()
        
        while not self.send_queue.empty():
            try:
                self.send_queue.get_nowait()
                self.send_queue.task_done()
            except:
                pass
        
        for worker in self.workers:
            if worker.is_alive():
                try:
                    worker.join(timeout=1)
                except:
                    pass
        
        for t in self.active_threads:
            if t.is_alive():
                try:
                    t.join(timeout=1)
                except:
                    pass
        
        self.workers.clear()
        self.active_threads.clear()
        self.stop_event.clear()
        
        print("Đã dừng tất cả threads!")
        
    def start_workers(self):
        """Khởi tạo các worker threads để xử lý tin nhắn"""
        for i in range(self.max_workers):
            worker = threading.Thread(target=self._worker_process, daemon=True)
            worker.start()
            self.workers.append(worker)
            self.active_threads.append(worker)
    
    def _worker_process(self):
        """Worker xử lý tin nhắn từ hàng đợi"""
        while not self.stop_event.is_set():
            try:
                text, thread_id, thread_type, mention, multi_mention = self.send_queue.get(timeout=0.5)
                if multi_mention:
                    self.send(Message(text=text, mention=multi_mention), thread_id, thread_type)
                elif mention:
                    self.send(Message(text=text, mention=mention), thread_id, thread_type)
                else:
                    self.send(Message(text=text), thread_id, thread_type)
                self.send_queue.task_done()
                time.sleep(0.01)
            except queue.Empty:
                continue
            except Exception as e:
                print(f"Worker error: {e}")
                self.send_queue.task_done()
                if self.stop_event.is_set():
                    break

    def send_message_multi_thread(self, lines, thread_id, thread_type, mention=None, tag_mode=False, multi_mention=None):
        """Gửi tin nhắn bằng nhiều luồng"""
        def worker_send():
            index = 0
            while self.auto_chatting and lines and not self.stop_event.is_set():
                try:
                    if multi_mention:
                        self.send_queue.put((lines[index % len(lines)], thread_id, thread_type, None, multi_mention))
                    elif tag_mode and mention:
                        traloi = lines[index % len(lines)] + " @member"
                        offset = len(lines[index % len(lines)]) + 1
                        mention_obj = Mention(mention, offset=offset, length=8)
                        self.send_queue.put((traloi, thread_id, thread_type, mention_obj, None))
                    else:
                        self.send_queue.put((lines[index % len(lines)], thread_id, thread_type, None, None))
                    
                    index += 1
                    time.sleep(0.001)
                    
                except Exception as e:
                    print(f"Send error: {e}")
                    break

        num_threads = min(self.max_workers, len(lines))
        threads = []
        for _ in range(num_threads):
            t = threading.Thread(target=worker_send, daemon=True)
            t.start()
            threads.append(t)
            self.active_threads.append(t)
        
        if not self.workers:
            self.start_workers()

    def sendTxt(self, filename, thread_id, thread_type, tag_mode=False, tagged_uid=None, multi_mention=None):
        """Gửi file text với multi-thread"""
        def auto_send():
            try:
                with open(filename, "r", encoding="utf-8") as f:
                    lines = [line.strip() for line in f if line.strip()]
                if not lines:
                    self.sendMessage(Message(text="File khong co gi"), thread_id, thread_type)
                    self.auto_chatting = False
                    return

                if not self.workers:
                    self.start_workers()

                self.send_message_multi_thread(
                    lines, 
                    thread_id, 
                    thread_type, 
                    mention=tagged_uid,
                    tag_mode=tag_mode,
                    multi_mention=multi_mention
                )

            except FileNotFoundError:
                self.sendMessage(Message(text=f"Not {filename}"), thread_id, thread_type)
                self.auto_chatting = False
            except Exception as e:
                self.sendMessage(Message(text=f"{str(e)}"), thread_id, thread_type)
                self.auto_chatting = False

        t = threading.Thread(target=auto_send, daemon=True)
        t.start()
        self.active_threads.append(t)

    def onMessage(self, mid, author_id, message, message_object, thread_id, thread_type):
        # CHỈ xử lý tin nhắn từ ID được phép
        if author_id != self.allowed_user_id:
            # Không in ra gì cả, bỏ qua hoàn toàn
            return
        
        # Chỉ in tin nhắn từ ID được phép
        print(f"[BOT] Tin nhắn từ {author_id}: {message}")
        
        # Xử lý tin nhắn từ ID được phép
        thread.submit(self.onHandle, mid, author_id, message, message_object, thread_id, thread_type)
        
        # Copy mode
        if self.copy_mode and author_id in self.copy_target:
            self.replyMessage(
                Message(text=message),
                message_object,
                thread_id=thread_id,
                thread_type=thread_type
            )
    
    def onHandle(self, mid, author_id, message, message_object, thread_id, thread_type):
        # Kiểm tra lại quyền truy cập
        if author_id != self.allowed_user_id:
            return
            
        # Lệnh dừng tất cả
        if message == f"{self.prefix}stop":
            self.stop_all_threads()
            self.sendMessage(Message(text="✅ Đã dừng tất cả threads và workers!"), thread_id, thread_type)
            return
            
        # Lệnh chức năng
        elif message == f"{self.prefix}help":
            mention = Mention(author_id, length=7, offset=0)
            color = MessageStyle(style="color", color="cdd6f4", offset=0, length=3000, auto_format=False)
            smallfont = MessageStyle(style="font", size="13", offset=0, length=3000, auto_format=False)
            style = MultiMsgStyle([color, smallfont])
            ds_menu = """
            ╔═══════════════════════════════╗
            ║      DANH SÁCH LỆNH BOT      ║
            ╠═══════════════════════════════╣
            ║ -help     : Hiển thị help    ║
            ║ -uid      : Lấy UID người    ║
            ║ -uptime   : Thời gian chạy   ║
            ║ -reset    : Reset bot        ║
            ║ -stop     : Dừng all threads ║
            ║ -1c       : Chế độ 1c        ║
            ║ -war      : Chế độ war       ║
            ║ -chui     : Chế độ chửi      ║
            ║ -so       : Chế độ sớ        ║
            ║ -nhay     : Chế độ nhây      ║
            ║ -copy     : Copy tin nhắn    ║
            ║ -treo     : Treo + ping all  ║
            ║ -tagall   : Tag all thành viên║
            ╚═══════════════════════════════╝
            """
            traloi = "@member "
            self.replyMessage(
                Message(text=traloi, style=style, mention=mention),
                message_object,
                thread_id=thread_id,
                thread_type=thread_type
            )
        
        elif message.startswith(f"{self.prefix}uid"):
            if message_object.mentions:
                tagged_users = message_object.mentions[0]['uid']
            else:
                tagged_users = author_id
            response_message = f"{tagged_users}"
            message_to_send = Message(text=response_message)
            self.replyMessage(message_to_send, message_object, thread_id, thread_type)

        elif message.startswith(f"{self.prefix}uptime"):
            uptime = time.time() - self.start_time
            days, remainder = divmod(uptime, 86400)
            hours, remainder = divmod(remainder, 3600)
            minutes, seconds = divmod(remainder, 60)
            uptime_str = f"{int(days)} days, {int(hours)} hours, {int(minutes)} minutes, {int(seconds)} seconds"
            self.sendMessage(Message(text=f"⏰ Uptime: {uptime_str}"), thread_id, thread_type)
        
        elif message.startswith(f"{self.prefix}reset"):
            self.sendMessage(Message(text="🔄 Đang khởi động lại bot..."), thread_id, thread_type)
            os.execv(sys.executable, [sys.executable] + sys.argv)

        # Lệnh war với multi-thread
        elif message.startswith(f"{self.prefix}1c"):
            if message.strip() == f"{self.prefix}1c off":
                self.auto_chatting = False
                self.sendMessage(Message(text="⏹️ Đã dừng chế độ 1c!"), thread_id, thread_type)
            else:
                if self.auto_chatting:
                    self.sendMessage(Message(text="⏳ Bot đang chạy, vui lòng tắt trước!"), thread_id, thread_type)
                else:
                    filename = "1c.txt"
                    self.auto_chatting = True
                    self.sendTxt(filename, thread_id, thread_type)

        elif message.startswith(f"{self.prefix}war"):
            if message.strip() == f"{self.prefix}war off":
                self.auto_chatting = False
                self.sendMessage(Message(text="⏹️ Đã dừng chế độ war!"), thread_id, thread_type)
            else:
                if self.auto_chatting:
                    self.sendMessage(Message(text="⏳ Bot đang chạy, vui lòng tắt trước!"), thread_id, thread_type)
                else:
                    filename = "nhay.txt"
                    self.auto_chatting = True
                    self.sendTxt(filename, thread_id, thread_type)

        elif message.startswith(f"{self.prefix}chui"):
            if message.strip() == f"{self.prefix}chui off":
                self.auto_chatting = False
                self.sendMessage(Message(text="⏹️ Đã dừng chế độ chửi!"), thread_id, thread_type)
            else:
                if self.auto_chatting:
                    self.sendMessage(Message(text="⏳ Bot đang chạy, vui lòng tắt trước!"), thread_id, thread_type)
                else:
                    if not message_object.mentions:
                        self.sendMessage(Message(text="⚠️ Tag người cần chửi!"), thread_id, thread_type)
                        return

                    filename = "nhay.txt"
                    self.auto_chatting = True
                    tagged_uid = message_object.mentions[0]['uid']
                    
                    self.sendTxt(filename, thread_id, thread_type, tag_mode=True, tagged_uid=tagged_uid)

        elif message.startswith(f"{self.prefix}so"):
            if message.strip() == f"{self.prefix}so off":
                self.auto_chatting = False
                self.sendMessage(Message(text="⏹️ Đã dừng chế độ sớ!"), thread_id, thread_type)
            else:
                if self.auto_chatting:
                    self.sendMessage(Message(text="⏳ Bot đang chạy, vui lòng tắt trước!"), thread_id, thread_type)
                else:
                    filename = "so.txt"
                    self.auto_chatting = True
                    self.sendTxt(filename, thread_id, thread_type)

        elif message.startswith(f"{self.prefix}nhay"):
            if message.strip() == f"{self.prefix}nhay off":
                self.auto_chatting = False
                self.sendMessage(Message(text="⏹️ Đã dừng chế độ nhây!"), thread_id, thread_type)
            else:
                if self.auto_chatting:
                    self.sendMessage(Message(text="⏳ Bot đang chạy, vui lòng tắt trước!"), thread_id, thread_type)
                else:
                    filename = "nhay.txt"
                    self.auto_chatting = True
                    self.sendTxt(filename, thread_id, thread_type)
        
        elif message.startswith(f"{self.prefix}copy"):
            if message.strip() == f"{self.prefix}copy off":
                self.copy_mode = False
                self.copy_target.clear()
                self.sendMessage(Message(text="📋 Copy mode OFF!"), thread_id, thread_type)
            elif message_object.mentions:
                self.copy_target = set(m['uid'] for m in message_object.mentions)
                self.copy_mode = True
                self.sendMessage(Message(text="📋 Copy mode ON!"), thread_id, thread_type)
            else:
                self.sendMessage(Message(text="⚠️ Tag người cần copy!"), thread_id, thread_type)

        elif message.startswith(f"{self.prefix}treo"):
            if message.strip() == f"{self.prefix}treo off":
                self.auto_chatting = False
                self.sendMessage(Message(text="⏹️ Đã dừng chế độ treo!"), thread_id, thread_type)
            else:
                if self.auto_chatting:
                    self.sendMessage(Message(text="⏳ Bot đang chạy, vui lòng tắt trước!"), thread_id, thread_type)
                else:
                    def send_treo_with_ping():
                        try:
                            with open("ngontreo.txt", "r", encoding="utf-8") as f:
                                content = f.read().strip()
                            if not content:
                                self.sendMessage(Message(text="⚠️ File không có nội dung!"), thread_id, thread_type)
                                return
                            
                            # Lấy danh sách thành viên trong nhóm
                            try:
                                group_info = self.fetchGroupInfo(thread_id).gridInfoMap[thread_id]
                                thanhvien = group_info.get('memVerList', [])
                                # Tạo mention cho tất cả thành viên
                                mention_list = []
                                for userId in thanhvien:
                                    uid = userId.split('_')[0]
                                    mention_list.append(Mention(uid, length=len(content) + 1, offset=0))
                                multi_mention = MultiMention(mention_list)
                            except Exception as e:
                                print(f"Error getting group members: {e}")
                                multi_mention = None
                            
                            self.auto_chatting = True
                            self.sendMessage(Message(text="✅ Đã bắt đầu chế độ treo + ping all!"), thread_id, thread_type)
                            
                            # Sử dụng multi-thread với ping all
                            if multi_mention:
                                lines = [content]
                                self.send_message_multi_thread(
                                    lines, 
                                    thread_id, 
                                    thread_type, 
                                    multi_mention=multi_mention
                                )
                            else:
                                # Nếu không có mention, gửi thường
                                while self.auto_chatting and not self.stop_event.is_set():
                                    for _ in range(5):
                                        if not self.auto_chatting or self.stop_event.is_set():
                                            break
                                        self.send_queue.put((content, thread_id, thread_type, None, None))
                                    time.sleep(0.5)
                                    
                        except Exception as e:
                            self.sendMessage(Message(text=f"⚠️ Lỗi: {e}"), thread_id, thread_type)
                            self.auto_chatting = False
                    
                    if not self.workers:
                        self.start_workers()
                    t = threading.Thread(target=send_treo_with_ping, daemon=True)
                    t.start()
                    self.active_threads.append(t)

        elif message.startswith(f"{self.prefix}xbdz"):
            if message.strip() == f"{self.prefix}xbdz off":
                self.auto_chatting = False
                self.sendMessage(Message(text="⏹️ Đã dừng chế độ xbdz!"), thread_id, thread_type)
            else:
                if self.auto_chatting:
                    self.sendMessage(Message(text="⏳ Bot đang chạy, vui lòng tắt trước!"), thread_id, thread_type)
                else:
                    def send_treotagall():
                        try:
                            with open("ngontreo.txt", "r", encoding="utf-8") as f:
                                content = f.read().strip()
                            if not content:
                                self.sendMessage(Message(text="⚠️ File không có nội dung!"), thread_id, thread_type)
                                return
                            self.auto_chatting = True
                            group_info = self.fetchGroupInfo(thread_id).gridInfoMap[thread_id]
                            thanhvien = group_info.get('memVerList', [])
                            mention = [Mention(userId.split('_')[0], length=len(content) + 1, offset=0) for userId in thanhvien]
                            wjxz_mention = MultiMention(mention)
                            
                            if not self.workers:
                                self.start_workers()
                            
                            self.sendMessage(Message(text="✅ Đã bắt đầu chế độ xbdz!"), thread_id, thread_type)
                            
                            while self.auto_chatting and not self.stop_event.is_set():
                                self.send_queue.put((content, thread_id, thread_type, None, wjxz_mention))
                                time.sleep(0.1)
                        except Exception as e:
                            self.sendMessage(Message(text=f"⚠️ Lỗi: {e}"), thread_id, thread_type)
                            self.auto_chatting = False
                    t = threading.Thread(target=send_treotagall, daemon=True)
                    t.start()
                    self.active_threads.append(t)

        elif message.startswith(f"{self.prefix}tagall"):
            if author_id not in self.idadmin:
                noquyen = "⚠️ Bạn không có quyền để thực hiện điều này!"
                style_error = MultiMsgStyle([
                    MessageStyle(offset=0, length=len(noquyen.encode()), style="font", size="13", auto_format=False),
                    MessageStyle(offset=0, length=len(noquyen.encode()), style="color", color="#ff6b6b", auto_format=False)
                ])
                self.replyMessage(Message(text=noquyen, style=style_error), message_object, thread_id, thread_type)
                return
            
            content = message.strip().split(' ', 1)
            if len(content) < 2:
                self.replyMessage(Message(text="⚠️ Vui lòng nhập nội dung!"), message_object, thread_id, thread_type)
                return
            try:
                wjx = content[1]
                group_info = self.fetchGroupInfo(thread_id).gridInfoMap[thread_id]
                thanhvien = group_info.get('memVerList', [])
                mention = [Mention(userId.split('_')[0], length=len(wjx) + 1, offset=0) for userId in thanhvien]
                wjxz_mention = MultiMention(mention)
                self.send(Message(text=wjx, mention=wjxz_mention), thread_id, thread_type)
            except Exception as e:
                print(f"Error: {e}")

bot = WxBotWar("<API_KEY>", "<SECRET_KEY>", imei=imei, session_cookies=cookies)
bot.listen()