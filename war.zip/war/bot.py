from zlapi import ZaloAPI
from zlapi.models import *
import time
from concurrent.futures import ThreadPoolExecutor
import threading
import os
import sys
import random
import json
import getpass
    
# File lưu thông tin đăng nhập
INFO_FILE = "in4.txt"

# === THÔNG TIN ADMIN (CHỈ SỬA Ở ĐÂY) ===
ADMIN_ID = "835355022821204140"  # Thay bằng UID của bạn
ADMIN_NAME = "Alex541 ( Russian/Vietnamese"  # Tên hiển thị của bạn

def load_info():
    """Đọc thông tin từ file in4.txt"""
    try:
        with open(INFO_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
            return data.get("imei"), data.get("cookies"), data.get("use_cookie", True)
    except (FileNotFoundError, json.JSONDecodeError):
        return None, None, True

def save_info(imei, cookies, use_cookie=True):
    """Lưu thông tin vào file in4.txt"""
    data = {
        "imei": imei,
        "cookies": cookies,
        "use_cookie": use_cookie
    }
    with open(INFO_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=4, ensure_ascii=False)

def get_imei():
    """Hỏi người dùng nhập IMEI"""
    print("\n" + "="*50)
    print("NHẬP IMEI")
    print("="*50)
    imei = input("IMEI (để trống nếu muốn dùng IMEI cũ): ").strip()
    if not imei:
        old_imei, _, _ = load_info()
        if old_imei:
            print(f"Sử dụng IMEI cũ: {old_imei}")
            return old_imei
        else:
            print("⚠️ Không tìm thấy IMEI cũ! Vui lòng nhập IMEI mới.")
            return get_imei()
    return imei

def get_cookies():
    """Hỏi người dùng nhập Cookies"""
    print("\n" + "="*50)
    print("NHẬP COOKIES")
    print("="*50)
    print("📌 Hướng dẫn lấy cookies:")
    print("1. Mở Zalo trên trình duyệt và đăng nhập")
    print("2. Nhấn F12 -> Application -> Cookies -> https://zalo.me")
    print("3. Copy toàn bộ cookies vào đây (dạng JSON)")
    print("="*50)
    
    use_cookie = input("Sử dụng cookies để đăng nhập? (y/n, mặc định y): ").strip().lower()
    if use_cookie == 'n':
        return None, False
    
    print("\n📝 Nhập cookies dạng JSON (hoặc để trống dùng cookies cũ):")
    cookies_input = input("Cookies: ").strip()
    
    if not cookies_input:
        _, old_cookies, _ = load_info()
        if old_cookies:
            print("Sử dụng cookies cũ")
            return old_cookies, True
        else:
            print("⚠️ Không tìm thấy cookies cũ! Vui lòng nhập cookies mới.")
            return get_cookies()
    
    try:
        # Thử parse JSON
        cookies = json.loads(cookies_input)
        if isinstance(cookies, dict):
            print("✅ Cookies hợp lệ!")
            return cookies, True
        else:
            print("❌ Cookies không đúng định dạng JSON!")
            return get_cookies()
    except json.JSONDecodeError:
        print("❌ JSON không hợp lệ! Vui lòng nhập đúng định dạng.")
        return get_cookies()

def get_credentials():
    """Hỏi người dùng nhập phone và password (cách khác)"""
    print("\n" + "="*50)
    print("ĐĂNG NHẬP BẰNG SỐ ĐIỆN THOẠI")
    print("="*50)
    phone = input("Số điện thoại: ").strip()
    if not phone:
        return None, None
    
    password = getpass.getpass("Mật khẩu: ").strip()
    if not password:
        print("❌ Mật khẩu không được để trống!")
        return get_credentials()
    
    return phone, password

def login_with_retry():
    """Thử đăng nhập, nếu lỗi thì hỏi lại thông tin"""
    imei, cookies, use_cookie = load_info()
    
    if not imei or not cookies:
        print("\n🔄 Lần đầu chạy, cần nhập thông tin đăng nhập!")
        imei = get_imei()
        cookies, use_cookie = get_cookies()
        save_info(imei, cookies, use_cookie)
    
    return imei, cookies, use_cookie

class WxBotWar(ZaloAPI):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.prefix = "-"
        self.admin_id = ADMIN_ID  # ID của admin
        self.admin_name = ADMIN_NAME
        self.auto_chatting = False
        self.start_time = time.time()
        self.copy_mode = False
        self.copy_target = set()
        self.spam_threads = []

    def is_admin(self, user_id):
        """Kiểm tra xem có phải admin không"""
        return str(user_id) == str(self.admin_id)

    def sendTxt(self, filename, thread_id, thread_type, speed=1, concurrent=3):
        def auto_send():
            try:
                with open(filename, "r", encoding="utf-8") as f:
                    lines = [line.strip() for line in f if line.strip()]
                if not lines:
                    self.sendMessage(Message(text="File khong co gi"), thread_id, thread_type)
                    self.auto_chatting = False
                    return

                def send_worker():
                    index = 0
                    while self.auto_chatting:
                        try:
                            self.sendMessage(Message(text=lines[index % len(lines)]), thread_id, thread_type)
                            index += 1
                            time.sleep(speed / concurrent)
                        except Exception as e:
                            print(f"Send error: {e}")
                            time.sleep(0.5)

                workers = []
                for _ in range(concurrent):
                    t = threading.Thread(target=send_worker)
                    t.daemon = True
                    t.start()
                    workers.append(t)
                    time.sleep(0.1)

                for t in workers:
                    t.join()

            except FileNotFoundError:
                self.sendMessage(Message(text=f"Not {filename}"), thread_id, thread_type)
                self.auto_chatting = False
            except Exception as e:
                self.sendMessage(Message(text=f"{str(e)}"), thread_id, thread_type)
                self.auto_chatting = False

        threading.Thread(target=auto_send, daemon=True).start()

    def onMessage(self, mid, author_id, message, message_object, thread_id, thread_type):
        # Kiểm tra nếu không phải admin thì không xử lý
        if not self.is_admin(author_id):
            # Vẫn hiển thị tin nhắn nhưng không xử lý
            print(f"⚠️ Tin nhắn từ người dùng thường: {author_id}: {message}")
            return
        
        thread.submit(self.onHandle, mid, author_id, message, message_object, thread_id, thread_type)
        print(f"✅ Tin nhắn từ Admin: {author_id}: {message}")
        
        if self.copy_mode and author_id in self.copy_target:
            self.replyMessage(
                Message(text=message),
                message_object,
                thread_id=thread_id,
                thread_type=thread_type
            )

    def onHandle(self, mid, author_id, message, message_object, thread_id, thread_type):
        # LỆNH HELP - Tag admin
        if message == f"{self.prefix}help":
            # Tạo mention cho admin
            mention = Mention(self.admin_id, length=len(self.admin_name), offset=0)
            
            # Style cho bảng
            color = MessageStyle(style="color", color="cdd6f4", offset=0, length=3000, auto_format=False)
            smallfont = MessageStyle(style="font", size="13", offset=0, length=3000, auto_format=False)
            style = MultiMsgStyle([color, smallfont])
            
            # Bảng menu đẹp hơn
            ds_menu = f"""
╔══════════════════════════════════════╗
║      📋 DANH SÁCH LỆNH BOT         ║
╠══════════════════════════════════════╣
║ {self.prefix}help     : Hiển thị danh sách lệnh ║
║ {self.prefix}uid      : Lấy UID người dùng      ║
║ {self.prefix}uptime   : Thời gian bot hoạt động ║
║ {self.prefix}reset    : Khởi động lại bot       ║
║ {self.prefix}1c       : Chế độ 1c               ║
║ {self.prefix}war      : Chế độ war              ║
║ {self.prefix}chui     : Chế độ chửi (tag)       ║
║ {self.prefix}so       : Chế độ sớ               ║
║ {self.prefix}nhay     : Chế độ nhây (spam cực)  ║
║ {self.prefix}copy     : Copy tin nhắn           ║
║ {self.prefix}treo     : Chế độ treo             ║
║ {self.prefix}tagall   : Tag tất cả thành viên   ║
║ {self.prefix}xbdz     : Treo + tagall           ║
╚══════════════════════════════════════╝
            """
            # Gửi tin nhắn với mention admin
            self.replyMessage(
                Message(text=f"@{self.admin_name} {ds_menu}", style=style, mention=mention),
                message_object,
                thread_id=thread_id,
                thread_type=thread_type
            )

        # LỆNH LẤY UID
        elif message.startswith(f"{self.prefix}uid"):
            if message_object.mentions:
                tagged_users = message_object.mentions[0]['uid']
            else:
                tagged_users = author_id
            response_message = f"UID: {tagged_users}"
            message_to_send = Message(text=response_message)
            self.replyMessage(message_to_send, message_object, thread_id, thread_type)

        # LỆNH UPTIME
        elif message.startswith(f"{self.prefix}uptime"):
            uptime = time.time() - self.start_time
            days, remainder = divmod(uptime, 86400)
            hours, remainder = divmod(remainder, 3600)
            minutes, seconds = divmod(remainder, 60)
            uptime_str = f"{int(days)} days, {int(hours)} hours, {int(minutes)} minutes, {int(seconds)} seconds"
            self.sendMessage(Message(text=f"⏰ Uptime: {uptime_str}"), thread_id, thread_type)
        
        # LỆNH RESET
        elif message.startswith(f"{self.prefix}reset"):
            self.sendMessage(Message(text="🔄 Đang khởi động lại bot..."), thread_id, thread_type)
            time.sleep(1)
            os.execv(sys.executable, [sys.executable] + sys.argv)

        # LỆNH 1C
        elif message.startswith(f"{self.prefix}1c"):
            if message.strip() == f"{self.prefix}1c off":
                self.auto_chatting = False
                self.sendMessage(Message(text="⏹️ Đã dừng chế độ 1c!"), thread_id, thread_type)
            else:
                if self.auto_chatting:
                    self.sendMessage(Message(text="⚠️ Bot đang chạy, vui lòng tắt trước!"), thread_id, thread_type)
                else:
                    filename = "1c.txt" 
                    self.auto_chatting = True
                    self.sendTxt(filename, thread_id, thread_type, speed=0.5, concurrent=5)
                    self.sendMessage(Message(text="▶️ Đã bật chế độ 1c!"), thread_id, thread_type)

        # LỆNH WAR
        elif message.startswith(f"{self.prefix}war"):
            if message.strip() == f"{self.prefix}war off":
                self.auto_chatting = False
                self.sendMessage(Message(text="⏹️ Đã dừng chế độ war!"), thread_id, thread_type)
            else:
                if self.auto_chatting:
                    self.sendMessage(Message(text="⚠️ Bot đang chạy, vui lòng tắt trước!"), thread_id, thread_type)
                else:
                    filename = "nhay.txt"
                    self.auto_chatting = True
                    self.sendTxt(filename, thread_id, thread_type, speed=0.3, concurrent=8)
                    self.sendMessage(Message(text="▶️ Đã bật chế độ war!"), thread_id, thread_type)

        # LỆNH CHỬI
        elif message.startswith(f"{self.prefix}chui"):
            if message.strip() == f"{self.prefix}chui off":
                self.auto_chatting = False
                self.sendMessage(Message(text="⏹️ Đã dừng chế độ chửi!"), thread_id, thread_type)
            else:
                if self.auto_chatting:
                    self.sendMessage(Message(text="⚠️ Bot đang chạy, vui lòng tắt trước!"), thread_id, thread_type)
                else:
                    if not message_object.mentions:
                        self.sendMessage(Message(text="❌ Vui lòng tag người cần chửi!"), thread_id, thread_type)
                        return

                    filename = "nhay.txt"
                    self.auto_chatting = True

                    def send_tagged():
                        try:
                            with open(filename, "r", encoding="utf-8") as f:
                                lines = [line.strip() for line in f if line.strip()]
                            if not lines:
                                self.sendMessage(Message(text="File không có gì"), thread_id, thread_type)
                                self.auto_chatting = False
                                return
                            tagged_uid = message_object.mentions[0]['uid']
                            
                            def tag_worker():
                                index = 0
                                while self.auto_chatting:
                                    try:
                                        traloi = lines[index % len(lines)] + " @member"
                                        offset = len(lines[index % len(lines)]) + 1
                                        mention = Mention(tagged_uid, offset=offset, length=8)
                                        self.send(
                                            Message(text=traloi, mention=mention),
                                            thread_id,
                                            thread_type
                                        )
                                        index += 1
                                        time.sleep(0.2)
                                    except Exception as e:
                                        print(f"Tag send error: {e}")
                                        time.sleep(0.5)
                            
                            workers = []
                            for _ in range(3):
                                t = threading.Thread(target=tag_worker)
                                t.daemon = True
                                t.start()
                                workers.append(t)
                            
                            for t in workers:
                                t.join()
                                
                        except FileNotFoundError:
                            self.sendMessage(Message(text=f"Không tìm thấy file {filename}"), thread_id, thread_type)
                            self.auto_chatting = False
                        except Exception as e:
                            self.sendMessage(Message(text=f"Lỗi: {str(e)}"), thread_id, thread_type)
                            self.auto_chatting = False

                    threading.Thread(target=send_tagged, daemon=True).start()
                    self.sendMessage(Message(text="▶️ Đã bật chế độ chửi!"), thread_id, thread_type)

        # LỆNH SỚ
        elif message.startswith(f"{self.prefix}so"):
            if message.strip() == f"{self.prefix}so off":
                self.auto_chatting = False
                self.sendMessage(Message(text="⏹️ Đã dừng chế độ sớ!"), thread_id, thread_type)
            else:
                if self.auto_chatting:
                    self.sendMessage(Message(text="⚠️ Bot đang chạy, vui lòng tắt trước!"), thread_id, thread_type)
                else:
                    filename = "so.txt" 
                    self.auto_chatting = True
                    self.sendTxt(filename, thread_id, thread_type, speed=0.5, concurrent=5)
                    self.sendMessage(Message(text="▶️ Đã bật chế độ sớ!"), thread_id, thread_type)

        # LỆNH NHAY (SPAM CỰC MẠNH)
        elif message.startswith(f"{self.prefix}nhay"):
            if message.strip() == f"{self.prefix}nhay off":
                self.auto_chatting = False
                self.sendMessage(Message(text="⏹️ Đã dừng chế độ nhây!"), thread_id, thread_type)
            else:
                if self.auto_chatting:
                    self.sendMessage(Message(text="⚠️ Bot đang chạy, vui lòng tắt trước!"), thread_id, thread_type)
                else:
                    filename = "nhay.txt" 
                    self.auto_chatting = True
                    self.sendTxt(filename, thread_id, thread_type, speed=0.2, concurrent=10)
                    self.sendMessage(Message(text="▶️ Đã bật chế độ nhây (spam cực mạnh)!"), thread_id, thread_type)
        
        # LỆNH COPY
        elif message.startswith(f"{self.prefix}copy"):
            if message.strip() == f"{self.prefix}copy off":
                self.copy_mode = False
                self.copy_target.clear()
                self.sendMessage(Message(text="⏹️ Đã tắt chế độ copy!"), thread_id, thread_type)
            elif message_object.mentions:
                self.copy_target = set(m['uid'] for m in message_object.mentions)
                self.copy_mode = True
                self.sendMessage(Message(text="▶️ Đã bật chế độ copy!"), thread_id, thread_type)
            else:
                self.sendMessage(Message(text="❌ Vui lòng tag người cần copy!"), thread_id, thread_type)

        # LỆNH TREO
        elif message.startswith(f"{self.prefix}treo"):
            if message.strip() == f"{self.prefix}treo off":
                self.auto_chatting = False
                self.sendMessage(Message(text="⏹️ Đã dừng chế độ treo!"), thread_id, thread_type)
            else:
                def send_all_repeat():
                    try:
                        with open("ngontreo.txt", "r", encoding="utf-8") as f:
                            content = f.read().strip()
                        if not content:
                            self.sendMessage(Message(text="File khong co gi"), thread_id, thread_type)
                            return
                        self.auto_chatting = True
                        
                        def repeat_worker():
                            while self.auto_chatting:
                                try:
                                    self.sendMessage(Message(text=content), thread_id, thread_type)
                                    time.sleep(1)
                                except Exception as e:
                                    print(f"Repeat error: {e}")
                                    time.sleep(0.5)
                        
                        workers = []
                        for _ in range(5):
                            t = threading.Thread(target=repeat_worker)
                            t.daemon = True
                            t.start()
                            workers.append(t)
                        
                        for t in workers:
                            t.join()
                            
                    except Exception as e:
                        self.sendMessage(Message(text=f"Lỗi: {e}"), thread_id, thread_type)
                        self.auto_chatting = False
                threading.Thread(target=send_all_repeat, daemon=True).start()
                self.sendMessage(Message(text="▶️ Đã bật chế độ treo!"), thread_id, thread_type)

        # LỆNH XBDZ (TREO + TAGALL)
        elif message.startswith(f"{self.prefix}xbdz"):
            if message.strip() == f"{self.prefix}xbdz off":
                self.auto_chatting = False
                self.sendMessage(Message(text="⏹️ Đã dừng chế độ xbdz!"), thread_id, thread_type)
            else:
                def send_treotagall():
                    try:
                        with open("ngontreo.txt", "r", encoding="utf-8") as f:
                            content = f.read().strip()
                        if not content:
                            self.sendMessage(Message(text="File khong co gi"), thread_id, thread_type)
                            return
                        self.auto_chatting = True
                        group_info = self.fetchGroupInfo(thread_id).gridInfoMap[thread_id]
                        thanhvien = group_info.get('memVerList', [])
                        mention = [Mention(userId.split('_')[0], length=3000, offset=0, auto_format=False) for userId in thanhvien]
                        wjxz_mention = MultiMention(mention)
                        
                        def tagall_worker():
                            while self.auto_chatting:
                                try:
                                    self.send(Message(text=content, mention=wjxz_mention), thread_id, thread_type)
                                    time.sleep(0.5)
                                except Exception as e:
                                    print(f"Tagall error: {e}")
                                    time.sleep(0.5)
                        
                        workers = []
                        for _ in range(3):
                            t = threading.Thread(target=tagall_worker)
                            t.daemon = True
                            t.start()
                            workers.append(t)
                        
                        for t in workers:
                            t.join()
                            
                    except Exception as e:
                        self.sendMessage(Message(text=f"Lỗi: {e}"), thread_id, thread_type)
                        self.auto_chatting = False
                threading.Thread(target=send_treotagall, daemon=True).start()
                self.sendMessage(Message(text="▶️ Đã bật chế độ xbdz (treo + tagall)!"), thread_id, thread_type)

        # LỆNH TAGALL
        elif message.startswith(f"{self.prefix}tagall"):
            content = message.strip().split(' ', 1)
            if len(content) < 2:
                self.replyMessage(Message(text="❌ Vui lòng nhập nội dung cần tag!"), message_object, thread_id, thread_type)
                return
            try:
                wjx = content[1]
                group_info = self.fetchGroupInfo(thread_id).gridInfoMap[thread_id]
                thanhvien = group_info.get('memVerList', [])
                mention = [Mention(userId.split('_')[0], length=3000, offset=0, auto_format=False) for userId in thanhvien]
                wjxz_mention = MultiMention(mention)
                self.send(Message(text=wjx, mention=wjxz_mention), thread_id, thread_type)
            except Exception as e:
                print(f"Error: {e}")
                self.sendMessage(Message(text=f"❌ Lỗi: {e}"), thread_id, thread_type)

def main():
    """Hàm chính để chạy bot"""
    print("\n" + "="*60)
    print("🤖 ZALO BOT WAR - MULTI THREAD SPAM")
    print("="*60)
    print(f"👤 Admin ID: {ADMIN_ID}")
    print(f"📛 Admin Name: {ADMIN_NAME}")
    print("="*60)
    
    # Load hoặc hỏi thông tin đăng nhập
    imei, cookies, use_cookie = login_with_retry()
    
    # Thử đăng nhập
    try:
        print("\n🔄 Đang đăng nhập vào Zalo...")
        if use_cookie and cookies:
            bot = WxBotWar(imei=imei, session_cookies=cookies)
            print("✅ Đăng nhập thành công bằng Cookies!")
        else:
            # Nếu không dùng cookie, hỏi số điện thoại và mật khẩu
            print("\n📱 Đăng nhập bằng số điện thoại")
            phone, password = get_credentials()
            if phone and password:
                bot = WxBotWar(phone=phone, password=password, imei=imei)
                print("✅ Đăng nhập thành công bằng số điện thoại!")
            else:
                print("❌ Không có thông tin đăng nhập!")
                return
        
        print("\n🚀 Bot đang chạy...")
        print("📌 Chỉ Admin mới có thể sử dụng bot!")
        print("📌 Lệnh help: -help")
        print("="*60 + "\n")
        bot.listen()
        
    except Exception as e:
        print(f"\n❌ Lỗi đăng nhập: {e}")
        print("\n🔄 Cookies có thể đã hết hạn! Hãy cập nhật cookies mới.")
        
        # Hỏi lại thông tin
        choice = input("\nBạn muốn:\n1. Nhập lại Cookies mới\n2. Nhập lại IMEI\n3. Thoát\nChọn (1/2/3): ").strip()
        
        if choice == "1":
            print("\n📝 Nhập cookies mới:")
            new_cookies, _ = get_cookies()
            if new_cookies:
                save_info(imei, new_cookies, True)
                print("✅ Đã lưu cookies mới! Khởi động lại bot...")
                time.sleep(2)
                os.execv(sys.executable, [sys.executable] + sys.argv)
            else:
                print("❌ Cookies không hợp lệ!")
        elif choice == "2":
            new_imei = get_imei()
            if new_imei:
                save_info(new_imei, cookies, True)
                print("✅ Đã lưu IMEI mới! Khởi động lại bot...")
                time.sleep(2)
                os.execv(sys.executable, [sys.executable] + sys.argv)
        else:
            print("👋 Tạm biệt!")

if __name__ == "__main__":
    main()