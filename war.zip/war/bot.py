from zlapi import ZaloAPI
from zlapi.models import *
import time
from concurrent.futures import ThreadPoolExecutor
import threading
import os
import sys
import queue
import signal

# Replace with your imei and cookies
imei = "imei"
cookies = {"cookie"}

thread = ThreadPoolExecutor(max_workers=10000)

class WxBotWar(ZaloAPI):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.prefix = "-"
        self.idadmin = ["12211212"]
        self.auto_chatting = False
        self.start_time = time.time()
        self.copy_mode = False
        self.copy_target = set()
        self.thread_pool = ThreadPoolExecutor(max_workers=20)
        self.send_queue = queue.Queue()
        self.workers = []
        self.max_workers = 10
        self.stop_event = threading.Event()  # Event để dừng tất cả threads
        self.active_threads = []  # Lưu trữ tất cả threads đang chạy
        
        # ID duy nhất được phép tương tác với bot
        self.allowed_user_id = "835355022821204140"
        
    def stop_all_threads(self):
        """Dừng tất cả threads và workers"""
        print("Đang dừng tất cả threads...")
        
        # Dừng auto_chatting
        self.auto_chatting = False
        
        # Set stop event
        self.stop_event.set()
        
        # Clear queue
        while not self.send_queue.empty():
            try:
                self.send_queue.get_nowait()
                self.send_queue.task_done()
            except:
                pass
        
        # Dừng tất cả worker threads
        for worker in self.workers:
            if worker.is_alive():
                try:
                    worker.join(timeout=1)
                except:
                    pass
        
        # Dừng tất cả active threads
        for t in self.active_threads:
            if t.is_alive():
                try:
                    t.join(timeout=1)
                except:
                    pass
        
        # Clear lists
        self.workers.clear()
        self.active_threads.clear()
        self.stop_event.clear()
        
        print("Đã dừng tất cả threads!")
        
    def start_workers(self):
        """Khởi tạo các worker threads để xử lý tin nhắn"""
        for i in range(self.max_workers):
            worker = threading.Thread(target=self._worker_process, daemon=True)
            worker.start()
            self.workers.append(worker)
            self.active_threads.append(worker)
    
    def _worker_process(self):
        """Worker xử lý tin nhắn từ hàng đợi"""
        while not self.stop_event.is_set():
            try:
                text, thread_id, thread_type, mention = self.send_queue.get(timeout=0.5)
                if mention:
                    self.send(Message(text=text, mention=mention), thread_id, thread_type)
                else:
                    self.send(Message(text=text), thread_id, thread_type)
                self.send_queue.task_done()
                time.sleep(0.01)
            except queue.Empty:
                continue
            except Exception as e:
                print(f"Worker error: {e}")
                self.send_queue.task_done()
                if self.stop_event.is_set():
                    break

    def send_message_multi_thread(self, lines, thread_id, thread_type, mention=None, tag_mode=False):
        """Gửi tin nhắn bằng nhiều luồng"""
        def worker_send():
            index = 0
            while self.auto_chatting and lines and not self.stop_event.is_set():
                try:
                    if tag_mode and mention:
                        traloi = lines[index % len(lines)] + " @member"
                        offset = len(lines[index % len(lines)]) + 1
                        mention_obj = Mention(mention, offset=offset, length=8)
                        self.send_queue.put((traloi, thread_id, thread_type, mention_obj))
                    else:
                        self.send_queue.put((lines[index % len(lines)], thread_id, thread_type, None))
                    
                    index += 1
                    time.sleep(0.001)
                    
                except Exception as e:
                    print(f"Send error: {e}")
                    break

        num_threads = min(self.max_workers, len(lines))
        threads = []
        for _ in range(num_threads):
            t = threading.Thread(target=worker_send, daemon=True)
            t.start()
            threads.append(t)
            self.active_threads.append(t)
        
        if not self.workers:
            self.start_workers()

    def sendTxt(self, filename, thread_id, thread_type, tag_mode=False, tagged_uid=None):
        """Gửi file text với multi-thread"""
        def auto_send():
            try:
                with open(filename, "r", encoding="utf-8") as f:
                    lines = [line.strip() for line in f if line.strip()]
                if not lines:
                    self.sendMessage(Message(text="File khong co gi"), thread_id, thread_type)
                    self.auto_chatting = False
                    return

                if not self.workers:
                    self.start_workers()

                self.send_message_multi_thread(
                    lines, 
                    thread_id, 
                    thread_type, 
                    mention=tagged_uid,
                    tag_mode=tag_mode
                )

            except FileNotFoundError:
                self.sendMessage(Message(text=f"Not {filename}"), thread_id, thread_type)
                self.auto_chatting = False
            except Exception as e:
                self.sendMessage(Message(text=f"{str(e)}"), thread_id, thread_type)
                self.auto_chatting = False

        t = threading.Thread(target=auto_send, daemon=True)
        t.start()
        self.active_threads.append(t)

    def onMessage(self, mid, author_id, message, message_object, thread_id, thread_type):
        # Kiểm tra xem người gửi có phải là ID được cho phép không
        if author_id != self.allowed_user_id:
            print(f"Tin nhắn từ người dùng không được phép: {author_id}")
            return
        
        print(f"Tin nhan tu ID duoc phep {author_id}: {message}")
        thread.submit(self.onHandle, mid, author_id, message, message_object, thread_id, thread_type)
        
        # Copy mode chỉ hoạt động với ID được phép
        if self.copy_mode and author_id in self.copy_target:
            self.replyMessage(
                Message(text=message),
                message_object,
                thread_id=thread_id,
                thread_type=thread_type
            )
    
    def onHandle(self, mid, author_id, message, message_object, thread_id, thread_type):
        # Kiểm tra lại quyền truy cập
        if author_id != self.allowed_user_id:
            return
            
        # Lệnh dừng tất cả
        if message == f"{self.prefix}stop":
            self.stop_all_threads()
            self.sendMessage(Message(text="✅ Đã dừng tất cả threads và workers!"), thread_id, thread_type)
            return
            
        # Lệnh chức năng
        elif message == f"{self.prefix}help":
            mention = Mention(author_id, length=7, offset=0)
            color = MessageStyle(style="color", color="cdd6f4", offset=0, length=3000, auto_format=False)
            smallfont = MessageStyle(style="font", size="13", offset=0, length=3000, auto_format=False)
            style = MultiMsgStyle([color, smallfont])
            ds_menu = """
            Danh sách lệnh:
            - {self.prefix}help: Hiển thị danh sách lệnh
            - {self.prefix}uid: Lấy UID của người dùng
            - {self.prefix}uptime: Xem thời gian hoạt động của bot
            - {self.prefix}reset: Khởi động lại bot
            - {self.prefix}stop: Dừng tất cả threads và workers
            - {self.prefix}1c: Chế độ 1c
            - {self.prefix}war: Chế độ war
            - {self.prefix}chui: Chế độ chửi
            - {self.prefix}so: Chế độ sớ
            - {self.prefix}nhay: Chế độ nhây
            - {self.prefix}copy: copy tin nhắn
            - {self.prefix}treo: Chế độ treo
            - {self.prefix}tagall: Tag tất cả thành viên trong nhóm

            """
            traloi = "@member "
            self.replyMessage(
                Message(text=traloi, style=style, mention=mention),
                message_object,
                thread_id=thread_id,
                thread_type=thread_type
            )
        
        elif message.startswith(f"{self.prefix}uid"):
            if message_object.mentions:
                tagged_users = message_object.mentions[0]['uid']
            else:
                tagged_users = author_id
            response_message = f"{tagged_users}"
            message_to_send = Message(text=response_message)
            self.replyMessage(message_to_send, message_object, thread_id, thread_type)

        elif message.startswith(f"{self.prefix}uptime"):
            uptime = time.time() - self.start_time
            days, remainder = divmod(uptime, 86400)
            hours, remainder = divmod(remainder, 3600)
            minutes, seconds = divmod(remainder, 60)
            uptime_str = f"{int(days)} days, {int(hours)} hours, {int(minutes)} minutes, {int(seconds)} seconds"
            self.sendMessage(Message(text=f"Uptime: {uptime_str}"), thread_id, thread_type)
        
        elif message.startswith(f"{self.prefix}reset"):
            self.sendMessage(Message(text="Đang khởi động lại bot..."), thread_id, thread_type)
            os.execv(sys.executable, [sys.executable] + sys.argv)

        # Lệnh war với multi-thread
        elif message.startswith(f"{self.prefix}1c"):
            if message.strip() == f"{self.prefix}1c off":
                self.auto_chatting = False
                self.sendMessage(Message(text="Stop!"), thread_id, thread_type)
            else:
                if self.auto_chatting:
                    self.sendMessage(Message(text=".."), thread_id, thread_type)
                else:
                    filename = "1c.txt"
                    self.auto_chatting = True
                    self.sendTxt(filename, thread_id, thread_type)

        elif message.startswith(f"{self.prefix}war"):
            if message.strip() == f"{self.prefix}war off":
                self.auto_chatting = False
                self.sendMessage(Message(text="Stop!"), thread_id, thread_type)
            else:
                if self.auto_chatting:
                    self.sendMessage(Message(text=".."), thread_id, thread_type)
                else:
                    filename = "nhay.txt"
                    self.auto_chatting = True
                    self.sendTxt(filename, thread_id, thread_type)

        elif message.startswith(f"{self.prefix}chui"):
            if message.strip() == f"{self.prefix}chui off":
                self.auto_chatting = False
                self.sendMessage(Message(text="Stop!"), thread_id, thread_type)
            else:
                if self.auto_chatting:
                    self.sendMessage(Message(text=".."), thread_id, thread_type)
                else:
                    if not message_object.mentions:
                        self.sendMessage(Message(text="Tag người cần chửi"), thread_id, thread_type)
                        return

                    filename = "nhay.txt"
                    self.auto_chatting = True
                    tagged_uid = message_object.mentions[0]['uid']
                    
                    self.sendTxt(filename, thread_id, thread_type, tag_mode=True, tagged_uid=tagged_uid)

        elif message.startswith(f"{self.prefix}so"):
            if message.strip() == f"{self.prefix}so off":
                self.auto_chatting = False
                self.sendMessage(Message(text="Stop!"), thread_id, thread_type)
            else:
                if self.auto_chatting:
                    self.sendMessage(Message(text=".."), thread_id, thread_type)
                else:
                    filename = "so.txt"
                    self.auto_chatting = True
                    self.sendTxt(filename, thread_id, thread_type)

        elif message.startswith(f"{self.prefix}nhay"):
            if message.strip() == f"{self.prefix}nhay off":
                self.auto_chatting = False
                self.sendMessage(Message(text="Stop!"), thread_id, thread_type)
            else:
                if self.auto_chatting:
                    self.sendMessage(Message(text=".."), thread_id, thread_type)
                else:
                    filename = "nhay.txt"
                    self.auto_chatting = True
                    self.sendTxt(filename, thread_id, thread_type)
        
        elif message.startswith(f"{self.prefix}copy"):
            if message.strip() == f"{self.prefix}copy off":
                self.copy_mode = False
                self.copy_target.clear()
                self.sendMessage(Message(text="Copy mode OFF!"), thread_id, thread_type)
            elif message_object.mentions:
                self.copy_target = set(m['uid'] for m in message_object.mentions)
                self.copy_mode = True
                self.sendMessage(Message(text="Copy mode ON!"), thread_id, thread_type)
            else:
                self.sendMessage(Message(text="Tag người cần copy!"), thread_id, thread_type)

        elif message.startswith(f"{self.prefix}treo"):
            if message.strip() == f"{self.prefix}treo off":
                self.auto_chatting = False
                self.sendMessage(Message(text="Stop!"), thread_id, thread_type)
            else:
                def send_all_repeat():
                    try:
                        with open("ngontreo.txt", "r", encoding="utf-8") as f:
                            content = f.read().strip()
                        if not content:
                            self.sendMessage(Message(text="File khong co gi"), thread_id, thread_type)
                            return
                        self.auto_chatting = True
                        
                        while self.auto_chatting and not self.stop_event.is_set():
                            for _ in range(5):
                                if not self.auto_chatting or self.stop_event.is_set():
                                    break
                                self.send_queue.put((content, thread_id, thread_type, None))
                            time.sleep(0.5)
                    except Exception as e:
                        self.sendMessage(Message(text=f"Lỗi: {e}"), thread_id, thread_type)
                        self.auto_chatting = False
                
                if not self.workers:
                    self.start_workers()
                t = threading.Thread(target=send_all_repeat, daemon=True)
                t.start()
                self.active_threads.append(t)

        elif message.startswith(f"{self.prefix}xbdz"):
            if message.strip() == f"{self.prefix}xbdz off":
                self.auto_chatting = False
                self.sendMessage(Message(text="Stop!"), thread_id, thread_type)
            else:
                def send_treotagall():
                    try:
                        with open("ngontreo.txt", "r", encoding="utf-8") as f:
                            content = f.read().strip()
                        if not content:
                            self.sendMessage(Message(text="File khong co gi"), thread_id, thread_type)
                            return
                        self.auto_chatting = True
                        group_info = self.fetchGroupInfo(thread_id).gridInfoMap[thread_id]
                        thanhvien = group_info.get('memVerList', [])
                        mention = [Mention(userId.split('_')[0], length=3000, offset=0, auto_format=False) for userId in thanhvien]
                        wjxz_mention = MultiMention(mention)
                        
                        if not self.workers:
                            self.start_workers()
                            
                        while self.auto_chatting and not self.stop_event.is_set():
                            self.send_queue.put((content, thread_id, thread_type, wjxz_mention))
                            time.sleep(0.1)
                    except Exception as e:
                        self.sendMessage(Message(text=f"Lỗi: {e}"), thread_id, thread_type)
                        self.auto_chatting = False
                t = threading.Thread(target=send_treotagall, daemon=True)
                t.start()
                self.active_threads.append(t)

        elif message.startswith(f"{self.prefix}tagall"):
            if author_id not in self.idadmin:
                noquyen = "Bạn không có quyền để thực hiện điều này!"
                style_error = MultiMsgStyle([
                    MessageStyle(offset=0, length=len(noquyen.encode()), style="font", size="13", auto_format=False),
                    MessageStyle(offset=0, length=len(noquyen.encode()), style="color", color="#cdd6f4", auto_format=False)
                ])
                self.replyMessage(Message(text=noquyen, style=style_error), message_object, thread_id, thread_type)
                return
            
            content = message.strip().split(' ', 1)
            if len(content) < 2:
                self.replyMessage(Message(text="Vui lòng nhập nội dung bé ơi"), message_object, thread_id, thread_type)
                return
            try:
                wjx = content[1]
                group_info = self.fetchGroupInfo(thread_id).gridInfoMap[thread_id]
                thanhvien = group_info.get('memVerList', [])
                mention = [Mention(userId.split('_')[0], length=3000, offset=0, auto_format=False) for userId in thanhvien]
                wjxz_mention = MultiMention(mention)
                self.send(Message(text=wjx, mention=wjxz_mention), thread_id, thread_type)
            except Exception as e:
                print(f"Error: {e}")

bot = WxBotWar("<API_KEY>", "<SECRET_KEY>", imei=imei, session_cookies=cookies)
bot.listen()